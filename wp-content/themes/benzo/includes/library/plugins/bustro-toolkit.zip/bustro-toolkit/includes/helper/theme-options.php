<?php
namespace BustroToolkit\Helper;

use CSF;

defined( 'ABSPATH' ) || exit;

/**
 * Bustro Toolkit Helper
 */

class Bustro_Theme_Options {
    protected static $instance = null;

    private $options_prefix = 'bustro_options';
    private $menu_slug      = 'bustro_options';
    private $template_builder_url;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function initialize() {
        if ( ! class_exists( 'CSF' ) ) {
            return;
        }

        $this->template_builder_url = admin_url( 'edit.php?post_type=bustro_template' );

        $this->theme_options();
        $this->preloader_section();
        $this->header_section();
        $this->page_title_section();
        $this->footer_section();
        $this->blog_section();
        $this->shop_section();
        $this->error_section();
        $this->search_section();
        $this->color_scheme_section();
        $this->typography_section();
        $this->custom_scrips_section();
        $this->backup_section();
    }

    /**
     * Create Theme Option
     */
    public function theme_options() {
        CSF::createOptions( $this->options_prefix, [
            'menu_title'         => esc_html__( 'Theme Options', 'bustro-toolkit' ),
            'menu_slug'          => $this->menu_slug,
            'framework_title'    => esc_html__( 'Bustro Options', 'bustro-toolkit' ),
            'show_in_customizer' => true,
            'menu_type'          => 'submenu',
            'menu_parent'        => 'bustro_dashboard',
        ] );
    }

    /**
     * Preloader option
     */
    public function preloader_section() {
        CSF::createSection( $this->options_prefix, [
            'title'  => esc_html__( 'Preloader', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Preloader', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'site_preloader',
                    'type'    => 'button_set',
                    'title'   => esc_html__( 'Preloader?', 'bustro-toolkit' ),
                    'options' => [
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default' => 'enabled',
                ],
                [
                    'id'          => 'preloader_background',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Preloader background', 'bustro-toolkit' ),
                    'output'      => '#preloader',
                    'output_mode' => 'background-color',
                    'dependency'  => [
                        'site_preloader', '==', 'enabled',
                    ],
                ],
                [
                    'id'         => 'preloader_image',
                    'type'       => 'media',
                    'title'      => esc_html__( 'Preloader Image', 'bustro-toolkit' ),
                    'library'    => 'image',
                    'default'    => [
                        'url'       => BT_ASSETS . '/img/options/preloader.gif',
                        'thumbnail' => BT_ASSETS . '/img/options/preloader.gif',
                    ],
                    'dependency' => [
                        'site_preloader', '==', 'enabled',
                    ],
                ],
            ],
        ] );
    }

    /**
     * Header Options
     */
    public function header_section() {
        CSF::createSection( $this->options_prefix, [
            'id'    => 'header_options',
            'title' => esc_html__( 'Header', 'bustro-toolkit' ),
        ] );

        CSF::createSection( $this->options_prefix, [
            'parent' => 'header_options',
            'title'  => esc_html__( 'General', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'General', 'bustro-toolkit' ),
                ],
                [
                    'type'    => 'notice',
                    'style'   => 'info',
                    'content' => esc_html__( 'If you used theme builder for site header then disable default theme header', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'default_header',
                    'type'     => 'button_set',
                    'title'    => esc_html__( 'Default Header', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Enable or Disable Theme default header', 'bustro-toolkit' ),
                    'options'  => [
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default'  => 'enabled',
                ],
                [
                    'type'       => 'notice',
                    'style'      => 'warning',
                    'content'    => esc_html__( 'You disabled default theme header. Set your site header form ', 'bustro-toolkit' ) . '<a href="' . esc_url( $this->template_builder_url ) . '">' . esc_html__( 'here', 'bustro-toolkit' ) . '</a>',
                    'dependency' => [
                        'default_header', '==', 'disabled',
                    ],
                ],
                [
                    'id'         => 'sticky_header',
                    'type'       => 'button_set',
                    'title'      => esc_html__( 'Sticky Header', 'bustro-toolkit' ),
                    'subtitle'   => esc_html__( 'It will stick header at the top when page scrolling', 'bustro-toolkit' ),
                    'options'    => [
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default'    => 'enabled',
                    'dependency' => [
                        'default_header', '==', 'enabled',
                    ],
                ],
                [
                    'id'         => 'header_breakpoint',
                    'type'       => 'number',
                    'title'      => esc_html__( 'Header Breakpoint', 'bustro-toolkit' ),
                    'default'    => 1200,
                    'desc'       => esc_html__( 'Enter when the slide menu will appear', 'bustro-toolkit' ),
                    'dependency' => [
                        'default_header', '==', 'enabled',
                    ],
                ],
            ],
        ] );

        CSF::createSection( $this->options_prefix, [
            'parent' => 'header_options',
            'title'  => esc_html__( 'Logo', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Logo', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'site_main_logo',
                    'type'    => 'media',
                    'title'   => esc_html__( 'Main logo', 'bustro-toolkit' ),
                    'library' => 'image',
                    'url'     => false,
                    'default' => [
                        'url'       => BT_ASSETS . '/img/options/logo.png',
                        'thumbnail' => BT_ASSETS . '/img/options/logo.png',
                    ],
                ],
                [
                    'id'     => 'logo_dimension',
                    'type'   => 'dimensions',
                    'title'  => esc_html__( 'Logo Dimensions', 'bustro-toolkit' ),
                    'output' => '.default-header .bustro-site-logo img',
                ],
                [
                    'id'      => 'slide_panel_logo',
                    'type'    => 'media',
                    'title'   => esc_html__( 'Slide Panel Logo', 'bustro-toolkit' ),
                    'library' => 'image',
                    'url'     => false,
                    'default' => [
                        'url'       => BT_ASSETS . '/img/options/logo.png',
                        'thumbnail' => BT_ASSETS . '/img/options/logo.png',
                    ],
                ],
                [
                    'id'     => 'slide_panel_dimension',
                    'type'   => 'dimensions',
                    'title'  => esc_html__( 'Logo Dimensions', 'bustro-toolkit' ),
                    'output' => '.default-header .slide-panel-logo img',
                ],
            ],
        ] );

        CSF::createSection( $this->options_prefix, [
            'parent' => 'header_options',
            'title'  => esc_html__( 'Styling', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Header Styling', 'bustro-toolkit' ),
                ],
                [
                    'id'          => 'header_bg',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Header Background', 'bustro-toolkit' ),
                    'output'      => ['.default-header'],
                    'output_mode' => 'background-color',
                ],
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Menu Items', 'bustro-toolkit' ),
                ],
                [
                    'id'          => 'menu_item_color',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Menu Item Color', 'bustro-toolkit' ),
                    'desc'        => esc_html__( 'This is the menu item font color.', 'bustro-toolkit' ),
                    'output'      => ['.default-header .bustro-nav-menu .nav-menu-wrapper a'],
                    'output_mode' => 'color',
                ],
                [
                    'id'          => 'menu_item_hover_color',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Active/Current Color', 'bustro-toolkit' ),
                    'desc'        => esc_html__( 'This is the menu item font color.', 'bustro-toolkit' ),
                    'output'      => ['.default-header .bustro-nav-menu .nav-menu-wrapper a:hover, .default-header .bustro-nav-menu .nav-menu-wrapper li.current_page_item > a'],
                    'output_mode' => 'color',
                ],
                [
                    'id'     => 'menu_typography',
                    'type'   => 'typography',
                    'title'  => esc_html__( 'Menu Typography', 'bustro-toolkit' ),
                    'color'  => false,
                    'output' => '.default-header .bustro-nav-menu .nav-menu-wrapper a',
                ],
                [
                    'type'    => 'subheading',
                    'content' => esc_html__( 'Submenu', 'bustro-toolkit' ),
                ],
                [
                    'id'          => 'submenu_bg',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Submenu Background', 'bustro-toolkit' ),
                    'output'      => '.default-header .bustro-nav-menu .nav-menu-wrapper .sub-menu',
                    'output_mode' => 'background-color',
                ],
                [
                    'id'          => 'submenu_item_divider',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Item Divider', 'bustro-toolkit' ),
                    'output'      => '.default-header .bustro-nav-menu .nav-menu-wrapper .sub-menu li:not(:last-child)',
                    'output_mode' => 'border-color',
                ],
                [
                    'id'          => 'submenu_item_color',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Item Color', 'bustro-toolkit' ),
                    'output'      => '.default-header .bustro-nav-menu .nav-menu-wrapper .sub-menu a',
                    'output_mode' => 'color',
                ],
                [
                    'id'          => 'submenu_item_hover_color',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Item Hover Color', 'bustro-toolkit' ),
                    'output'      => '.default-header .bustro-nav-menu .nav-menu-wrapper .sub-menu a:hover',
                    'output_mode' => 'color',
                ],
                [
                    'id'     => 'submenu_typography',
                    'type'   => 'typography',
                    'title'  => esc_html__( 'Item Typography', 'bustro-toolkit' ),
                    'color'  => false,
                    'output' => '.default-header .bustro-nav-menu .nav-menu-wrapper .sub-menu a',
                ],
                [
                    'type'    => 'subheading',
                    'content' => esc_html__( 'Slide Panel', 'bustro-toolkit' ),
                ],
                [
                    'id'     => 'toggler_color',
                    'type'   => 'color',
                    'title'  => esc_html__( 'Toggler Color', 'bustro-toolkit' ),
                    'output' => [
                        'border-color'     => '.default-header .bustro-nav-menu .navbar-toggler',
                        'background-color' => '.default-header .bustro-nav-menu .navbar-toggler .line',
                    ],
                ],
                [
                    'id'          => 'slide_panel_bg',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Background', 'bustro-toolkit' ),
                    'output'      => '.default-header .bustro-nav-menu .slide-panel-wrapper.show-panel .slide-panel-content',
                    'output_mode' => 'background-color',
                ],
                [
                    'id'          => 'panel_item_divider',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Item Divider', 'bustro-toolkit' ),
                    'output'      => ['.default-header .bustro-nav-menu .slide-panel-wrapper .slide-panel-menu a', '.default-header .bustro-nav-menu .slide-panel-wrapper ul.primary-menu'],
                    'output_mode' => 'border-color',
                ],
                [
                    'id'          => 'panel_item_color',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Item Color', 'bustro-toolkit' ),
                    'output'      => ['.default-header .bustro-nav-menu .slide-panel-wrapper .slide-panel-menu a', '.default-header .bustro-nav-menu .slide-panel-wrapper .slide-panel-close'],
                    'output_mode' => 'color',
                ],
                [
                    'id'          => 'panel_item_hover_color',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Item Hover Color', 'bustro-toolkit' ),
                    'output'      => '.default-header .bustro-nav-menu .slide-panel-wrapper .slide-panel-menu li.current_page_item > a',
                    'output_mode' => 'color',
                ],
                [
                    'id'     => 'panel_typography',
                    'type'   => 'typography',
                    'title'  => esc_html__( 'Item Typography', 'bustro-toolkit' ),
                    'color'  => false,
                    'output' => '.default-header .bustro-nav-menu .slide-panel-wrapper .slide-panel-menu a',
                ],
            ],
        ] );
    }

    /**
     * Page Title
     */
    public function page_title_section() {
        CSF::createSection( $this->options_prefix, [
            'title'  => esc_html__( 'Page Title', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Page Title', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'site_page_title',
                    'type'    => 'button_set',
                    'title'   => esc_html__( 'Site Page Title', 'bustro-toolkit' ),
                    'options' => [
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default' => 'enabled',
                ],
                [
                    'id'         => 'site_breadcrumb',
                    'type'       => 'button_set',
                    'title'      => esc_html__( 'Site Breadcrumb', 'bustro-toolkit' ),
                    'options'    => [
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default'    => 'enabled',
                    'dependency' => ['site_page_title', '==', 'enabled'],
                ],
                [
                    'type'       => 'subheading',
                    'content'    => esc_html__( 'Page Title Styling', 'bustro-toolkit' ),
                    'dependency' => ['site_page_title', '==', 'enabled'],
                ],
                [
                    'id'          => 'page_title_padding',
                    'type'        => 'spacing',
                    'title'       => esc_html__( 'Padding', 'bustro-toolkit' ),
                    'output'      => '.page-title-area',
                    'output_mode' => 'padding',
                ],
                [
                    'id'     => 'page_title_border',
                    'type'   => 'border',
                    'title'  => esc_html__( 'Border', 'bustro-toolkit' ),
                    'output' => '.page-title-area',
                ],
                [
                    'id'          => 'page_title_bg',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Background Color', 'bustro-toolkit' ),
                    'output'      => '.page-title-area',
                    'output_mode' => 'background-color',
                ],
                [
                    'id'     => 'page_title_typo',
                    'type'   => 'typography',
                    'title'  => esc_html( 'Typography', 'bustro-toolkit' ),
                    'output' => '.page-title-area .page-title',
                ],
                [
                    'id'     => 'page_breadcrumb_typo',
                    'type'   => 'typography',
                    'title'  => esc_html( 'Breadcrumb Typography', 'bustro-toolkit' ),
                    'output' => '.page-title-area .breadcrumb, .page-title-area .breadcrumb a',
                ],
                [
                    'id'          => 'page_title_dot',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Dots Color', 'bustro-toolkit' ),
                    'output'      => '.page-title-area .breadcrumb::before',
                    'output_mode' => 'background-color',
                ],
            ],
        ] );
    }

    /**
     * Footer Options
     */
    public function footer_section() {
        CSF::createSection( $this->options_prefix, [
            'id'    => 'footer_options',
            'title' => esc_html__( 'Footer', 'bustro-toolkit' ),
        ] );

        CSF::createSection( $this->options_prefix, [
            'parent' => 'footer_options',
            'title'  => esc_html__( 'General', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'General', 'bustro-toolkit' ),
                ],
                [
                    'type'    => 'notice',
                    'style'   => 'info',
                    'content' => esc_html__( 'If you used theme builder for site footer then disable default theme header', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'default_footer',
                    'type'     => 'button_set',
                    'title'    => esc_html__( 'Default Footer', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Enable or Disable Theme default footer', 'bustro-toolkit' ),
                    'options'  => [
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default'  => 'enabled',
                ],
                [
                    'type'       => 'notice',
                    'style'      => 'warning',
                    'content'    => esc_html__( 'You disabled default theme footer. Set your site footer form ', 'bustro-toolkit' ) . '<a href="' . esc_url( $this->template_builder_url ) . '">' . esc_html__( 'here', 'bustro-toolkit' ) . '</a>',
                    'dependency' => [
                        'default_footer', '==', 'disabled',
                    ],
                ],
            ],
        ] );

        CSF::createSection( $this->options_prefix, [
            'parent' => 'footer_options',
            'title'  => esc_html__( 'Footer Widgets', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Footer Widgets', 'bustro-toolkit' ),
                ],
                [
                    'id'     => 'footer_background',
                    'type'   => 'background',
                    'title'  => esc_html__( 'Footer background', 'bustro-toolkit' ),
                    'output' => '.site-default-footer',
                ],
                [
                    'id'     => 'footer_text_color',
                    'type'   => 'color',
                    'title'  => esc_html__( 'Text Color', 'bustro-toolkit' ),
                    'output' => [
                        'color' => '.footer-widgets .widget, .footer-widgets .widget a, .footer-widgets .widget.widget_pages a::before, .footer-widgets .widget.widget_pages a, .footer-widgets .widget.widget_meta a::before, .footer-widgets .widget.widget_meta a, .footer-widgets .widget.widget_nav_menu a::before, .footer-widgets .widget.widget_nav_menu a, .footer-widgets .widget.widget_recent_entries a::before, .footer-widgets .widget.widget_recent_entries a, .footer-widgets .widget.widget_block .wp-block-categories a, .footer-widgets .widget.widget_block .wp-block-archives a, .footer-widgets .widget.widget_categories a, .footer-widgets .widget.widget_archive a, .footer-widgets .widget.widget_tag_cloud .wp-block-tag-cloud a, .footer-widgets .widget.widget_tag_cloud .tagcloud a, .footer-widgets .widget.widget_block .wp-block-latest-comments a, .footer-widgets .widget.widget_recent_comments a',
                    ],
                ],
                [
                    'id'     => 'footer_text_hover_color',
                    'type'   => 'color',
                    'title'  => esc_html__( 'Hover Color', 'bustro-toolkit' ),
                    'output' => [
                        'color'            => '.footer-widgets .widget.widget_pages a:hover, .footer-widgets .widget.widget_meta a:hover, .footer-widgets .widget.widget_nav_menu a:hover, .footer-widgets .widget.widget_recent_entries a:hover, .footer-widgets .widget.widget_block .wp-block-categories a:hover, .footer-widgets .widget.widget_block .wp-block-archives a:hover, .footer-widgets .widget.widget_categories a:hover, .footer-widgets .widget.widget_archive a:hover, .footer-widgets .widget.widget_rss a.rsswidget:hover, .footer-widgets .widget.widget_block .wp-block-latest-comments a:hover, .footer-widgets .widget.widget_recent_comments a:hover',
                        'border-color'     => '.footer-widgets .widget.widget_tag_cloud .wp-block-tag-cloud a:hover, .footer-widgets .widget.widget_tag_cloud .tagcloud a:hover',
                        'background-color' => '.footer-widgets .widget.widget_tag_cloud .wp-block-tag-cloud a:hover, .footer-widgets .widget.widget_tag_cloud .tagcloud a:hover, .footer-widgets .widget.widget_search button, .footer-widgets .widget.widget_search button:hover',
                    ],
                ],
                [
                    'id'               => 'footer_content_typography',
                    'type'             => 'typography',
                    'title'            => esc_html__( 'Content Typography', 'bustro-toolkit' ),
                    'color'            => false,
                    'line_height_unit' => 'em',
                    'preview'          => false,
                    'output'           => ['.site-footer .footer-widgets .widget'],
                ],
                [
                    'type'    => 'subheading',
                    'content' => esc_html__( 'Widget Title', 'bustro-toolkit' ),
                ],
                [
                    'id'               => 'footer_title_typography',
                    'type'             => 'typography',
                    'title'            => esc_html__( 'Title', 'bustro-toolkit' ),
                    'output'           => '.footer-widgets .widget .widget-title',
                    'color'            => false,
                    'line_height_unit' => 'em',
                    'preview'          => false,
                ],
                [
                    'id'     => 'footer_title_color',
                    'type'   => 'color',
                    'title'  => esc_html__( 'Color', 'bustro-toolkit' ),
                    'output' => '.footer-widgets .widget .widget-title, .footer-widgets .widget.widget_rss a.rsswidget',
                ],
            ],
        ] );

        CSF::createSection( $this->options_prefix, [
            'parent' => 'footer_options',
            'title'  => esc_html__( 'Footer Copyright', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Footer', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'copyright_text',
                    'type'    => 'textarea',
                    'title'   => esc_html__( 'Copyright Text', 'bustro-toolkit' ),
                    'default' => esc_html__( 'Copyright © 2022. All rights reserved.', 'bustro-toolkit' ),
                ],
                [
                    'type'    => 'subheading',
                    'content' => esc_html__( 'Style', 'bustro-toolkit' ),
                ],
                [
                    'id'     => 'copyright_color',
                    'type'   => 'color',
                    'title'  => esc_html__( 'Copyright text color', 'bustro-toolkit' ),
                    'output' => '.site-default-footer .footer-copyright, .site-default-footer .footer-copyright a',
                ],
            ],
        ] );
    }

    /**
     * Blog Options
     */
    public function blog_section() {
        CSF::createSection( $this->options_prefix, [
            'id'    => 'blog_options',
            'title' => esc_html__( 'Blog', 'bustro-toolkit' ),
        ] );

        CSF::createSection( $this->options_prefix, [
            'parent' => 'blog_options',
            'title'  => esc_html__( 'Blog Archive', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Blog Archive', 'bustro-toolkit' ),
                ],
                [
                    'id'          => 'blog_archive_title',
                    'type'        => 'text',
                    'title'       => esc_html__( 'Blog Archive Title', 'bustro-toolkit' ),
                    'placeholder' => esc_html__( 'Type title', 'bustro-toolkit' ),
                    'default'     => esc_html__( 'Latest News', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'blog_archive_layout',
                    'type'    => 'image_select',
                    'title'   => esc_html__( 'Archive Layout', 'bustro-toolkit' ),
                    'options' => [
                        'boxed-layout'      => BT_ASSETS . '/img/options/boxed-layout.jpg',
                        'full-width-layout' => BT_ASSETS . '/img/options/full-width-layout.jpg',
                    ],
                    'default' => 'boxed-layout',
                    'desc'    => esc_html__( 'Select Archive layout. Full width or In container.  Settings will also apply on the blog category and tag archive pages', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'blog_archive_sidebar',
                    'type'    => 'image_select',
                    'title'   => esc_html__( 'Sidebar', 'bustro-toolkit' ),
                    'options' => [
                        'left-sidebar'  => BT_ASSETS . '/img/options/left-sidebar.jpg',
                        'right-sidebar' => BT_ASSETS . '/img/options/right-sidebar.jpg',
                        'no-sidebar'    => BT_ASSETS . '/img/options/no-sidebar.jpg',
                    ],
                    'default' => 'right-sidebar',
                    'desc'    => esc_html__( 'Select Page Sidebar. Left sidebar or right sidebar or No sidebar', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'archive_post_meta',
                    'type'     => 'button_set',
                    'title'    => esc_html__( 'Show Post Meta', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Enable or Disable Post meta on Blog Archive page', 'bustro-toolkit' ),
                    'options'  => [
                        'yes' => esc_html__( 'Yes', 'bustro-toolkit' ),
                        'no'  => esc_html__( 'No', 'bustro-toolkit' ),
                    ],
                    'default'  => 'yes',
                ],
                [
                    'id'       => 'archive_post_excerpt',
                    'type'     => 'button_set',
                    'title'    => esc_html__( 'Show Post Excerpt', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Enable or Disable Post Excerpt on Blog Archive page', 'bustro-toolkit' ),
                    'options'  => [
                        'yes' => esc_html__( 'Yes', 'bustro-toolkit' ),
                        'no'  => esc_html__( 'No', 'bustro-toolkit' ),
                    ],
                    'default'  => 'yes',
                ],
                [
                    'id'         => 'post_excerpt_count',
                    'type'       => 'number',
                    'title'      => esc_html__( 'Excerpt Word Count', 'bustro-toolkit' ),
                    'subtitle'   => esc_html__( 'Set how many words you want to show in the post Excerpt', 'bustro-toolkit' ),
                    'default'    => 35,
                    'dependency' => [
                        'archive_post_excerpt', '==', 'yes',
                    ],
                ],
                [
                    'id'       => 'archive_post_button',
                    'type'     => 'button_set',
                    'title'    => esc_html__( 'Show Read More Button', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Enable or Disable Post Read More Button on Blog Archive page', 'bustro-toolkit' ),
                    'options'  => [
                        'yes' => esc_html__( 'Yes', 'bustro-toolkit' ),
                        'no'  => esc_html__( 'No', 'bustro-toolkit' ),
                    ],
                    'default'  => 'yes',
                ],
                [
                    'id'         => 'post_button_text',
                    'type'       => 'text',
                    'title'      => esc_html__( 'Button Text', 'bustro-toolkit' ),
                    'default'    => esc_html__( 'Continue Reading', 'bustro-toolkit' ),
                    'dependency' => [
                        'archive_post_button', '==', 'yes',
                    ],
                ],
            ],
        ] );

        CSF::createSection( $this->options_prefix, [
            'parent' => 'blog_options',
            'title'  => esc_html__( 'Blog Single', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Blog single', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'blog_details_layout',
                    'type'    => 'image_select',
                    'title'   => esc_html__( 'Details Layout', 'bustro-toolkit' ),
                    'options' => [
                        'boxed-layout'      => BT_ASSETS . '/img/options/boxed-layout.jpg',
                        'full-width-layout' => BT_ASSETS . '/img/options/full-width-layout.jpg',
                    ],
                    'default' => 'boxed-layout',
                    'desc'    => esc_html__( 'Select Blog details layout. Full width or In container', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'blog_details_sidebar',
                    'type'    => 'image_select',
                    'title'   => esc_html__( 'Sidebar', 'bustro-toolkit' ),
                    'options' => [
                        'left-sidebar'  => BT_ASSETS . '/img/options/left-sidebar.jpg',
                        'right-sidebar' => BT_ASSETS . '/img/options/right-sidebar.jpg',
                        'no-sidebar'    => BT_ASSETS . '/img/options/no-sidebar.jpg',
                    ],
                    'default' => 'right-sidebar',
                    'desc'    => esc_html__( 'Select Blog Details Sidebar. Left sidebar or right sidebar or No sidebar', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'blog_details_meta',
                    'type'     => 'button_set',
                    'title'    => esc_html__( 'Show Post Meta', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Enable or Disable Post meta on Blog Details page', 'bustro-toolkit' ),
                    'options'  => [
                        'yes' => esc_html__( 'Yes', 'bustro-toolkit' ),
                        'no'  => esc_html__( 'No', 'bustro-toolkit' ),
                    ],
                    'default'  => 'yes',
                ],
                [
                    'id'       => 'blog_details_share',
                    'type'     => 'button_set',
                    'title'    => esc_html__( 'Show Post Share Links', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Enable or Disable Post social share links.', 'bustro-toolkit' ),
                    'options'  => [
                        'yes' => esc_html__( 'Yes', 'bustro-toolkit' ),
                        'no'  => esc_html__( 'No', 'bustro-toolkit' ),
                    ],
                    'default'  => 'no',
                ],
                [
                    'id'         => 'social_share_item',
                    'type'       => 'sorter',
                    'title'      => esc_html__( 'Social Share Links', 'bustro-toolkit' ),
                    'default'    => [
                        'enabled'  => [
                            'facebook'  => esc_html__( 'Facebook', 'bustro-toolkit' ),
                            'twitter'   => esc_html__( 'Twitter', 'bustro-toolkit' ),
                            'pinterest' => esc_html__( 'Pinterest', 'bustro-toolkit' ),
                            'linkedin'  => esc_html__( 'Linkedin', 'bustro-toolkit' ),
                        ],
                        'disabled' => [
                            'reddit'   => esc_html__( 'Reddit', 'bustro-toolkit' ),
                            'whatsapp' => esc_html__( 'Whatsapp', 'bustro-toolkit' ),
                            'telegram' => esc_html__( 'Telegram', 'bustro-toolkit' ),
                        ],
                    ],
                    'dependency' => [
                        'blog_details_share', '==', 'yes',
                    ],
                ],
                [
                    'id'       => 'blog_details_tag',
                    'type'     => 'button_set',
                    'title'    => esc_html__( 'Show Related Tags', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Enable or Disable related tag on Blog Details page', 'bustro-toolkit' ),
                    'options'  => [
                        'yes' => esc_html__( 'Yes', 'bustro-toolkit' ),
                        'no'  => esc_html__( 'No', 'bustro-toolkit' ),
                    ],
                    'default'  => 'yes',
                ],
                [
                    'id'       => 'blog_details_nav',
                    'type'     => 'button_set',
                    'title'    => esc_html__( 'Show Post Nav', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Enable or Disable Post nav on Blog Details page', 'bustro-toolkit' ),
                    'options'  => [
                        'yes' => esc_html__( 'Yes', 'bustro-toolkit' ),
                        'no'  => esc_html__( 'No', 'bustro-toolkit' ),
                    ],
                    'default'  => 'yes',
                ],
            ],
        ] );
    }

    /**
     * Shop Options
     */
    public function shop_section() {
        CSF::createSection( $this->options_prefix, [
            'title'  => esc_html__( 'Shop', 'bustro-toolkit' ),
            'fields' => [

            ],
        ] );
    }

    /**
     * Error Options
     */
    public function error_section() {
        CSF::createSection( $this->options_prefix, [
            'title'  => esc_html__( 'Error 404', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Error Page', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'error_note',
                    'type'    => 'textarea',
                    'title'   => esc_html__( 'Error Page Note', 'bustro-toolkit' ),
                    'default' => esc_html__( 'The page you are looking for doesn&rsquo;t exist. It may have been moved or removed altogether. Please try searching for some other page, or return to the website&rsquo;s homepage to find what you&rsquo;re looking for.', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'error_button_text',
                    'type'    => 'text',
                    'title'   => esc_html__( 'Error Button Text', 'bustro-toolkit' ),
                    'default' => esc_html__( 'Return To Home.', 'bustro-toolkit' ),
                ],
            ],
        ] );
    }

    /**
     * Search Options
     */
    public function search_section() {
        CSF::createSection( $this->options_prefix, [
            'title'  => esc_html__( 'Search Result', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Search Page', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'show_search_form',
                    'type'     => 'switcher',
                    'title'    => esc_html__( 'Show Search Form', 'bustro-toolkit' ),
                    'text_on'  => esc_html__( 'Yes', 'bustro-toolkit' ),
                    'text_off' => esc_html__( 'No', 'bustro-toolkit' ),
                    'default'  => true,
                ],
                [
                    'id'         => 'search_form_title',
                    'type'       => 'text',
                    'title'      => esc_html__( 'Form Title', 'bustro-toolkit' ),
                    'default'    => esc_html__( 'Search Here:', 'bustro-toolkit' ),
                    'dependency' => [
                        'show_search_form', '==', 'true',
                    ],
                ],
                [
                    'id'         => 'search_form_note',
                    'type'       => 'textarea',
                    'title'      => esc_html__( 'Form Note', 'bustro-toolkit' ),
                    'default'    => esc_html__( 'If you are not happy with the results below please do another search', 'bustro-toolkit' ),
                    'dependency' => [
                        'show_search_form', '==', 'true',
                    ],
                ],
            ],
        ] );
    }

    /**
     * Color Options
     */
    public function color_scheme_section() {
        CSF::createSection( $this->options_prefix, [
            'title'  => esc_html__( 'Color Scheme', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Color Scheme', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'primary_color',
                    'type'     => 'color',
                    'title'    => esc_html__( 'Primary Color', 'bustro-toolkit' ),
                    'default'  => '#fb2614',
                    'subtitle' => esc_html__( 'Default: #fb2614', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'secondary_color',
                    'type'     => 'color',
                    'title'    => esc_html__( 'Secondary Color', 'bustro-toolkit' ),
                    'default'  => '#000000',
                    'subtitle' => esc_html__( 'Default: #000000', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'body_color',
                    'type'     => 'color',
                    'title'    => esc_html__( 'Body Color', 'bustro-toolkit' ),
                    'default'  => '#636465',
                    'subtitle' => esc_html__( 'Default: #636465', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'border_color',
                    'type'     => 'color',
                    'title'    => esc_html__( 'Common Border Color', 'bustro-toolkit' ),
                    'default'  => '#eaeaea',
                    'subtitle' => esc_html__( 'Default: #eaeaea', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'light_color',
                    'type'     => 'color',
                    'title'    => esc_html__( 'Common Light Color', 'bustro-toolkit' ),
                    'default'  => '#f6f6f6',
                    'subtitle' => esc_html__( 'Default: #f6f6f6', 'bustro-toolkit' ),
                ],
            ],
        ] );
    }

    /**
     * Typography Options
     */
    public function typography_section() {
        CSF::createSection( $this->options_prefix, [
            'title'  => esc_html__( 'Typography', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Typography', 'bustro-toolkit' ),
                ],
                [
                    'id'                 => 'primary_font',
                    'type'               => 'typography',
                    'title'              => esc_html__( 'Primary Font', 'bustro-toolkit' ),
                    'font_weight'        => true,
                    'font_style'         => true,
                    'extra_styles'       => true,
                    'font_size'          => false,
                    'line_height'        => false,
                    'letter_spacing'     => false,
                    'text_align'         => false,
                    'text_transform'     => false,
                    'color'              => false,
                    'backup_font_family' => false,
                    'subset'             => true,
                    'preview'            => false,
                ],
                [
                    'id'                 => 'secondary_font',
                    'type'               => 'typography',
                    'title'              => esc_html__( 'Secondary Font', 'bustro-toolkit' ),
                    'font_weight'        => true,
                    'font_style'         => true,
                    'extra_styles'       => true,
                    'font_size'          => false,
                    'line_height'        => false,
                    'letter_spacing'     => false,
                    'text_align'         => false,
                    'text_transform'     => false,
                    'color'              => false,
                    'backup_font_family' => false,
                    'subset'             => true,
                    'preview'            => false,
                ],
                [
                    'id'      => 'body_typo_types',
                    'type'    => 'button_set',
                    'title'   => esc_html__( 'Body Typography', 'bustro-toolkit' ),
                    'options' => [
                        'default-font' => esc_html__( 'Default', 'bustro-toolkit' ),
                        'custom-font'  => esc_html__( 'Custom', 'bustro-toolkit' ),
                    ],
                    'default' => 'default-font',
                ],
                [
                    'id'               => 'body_typo',
                    'type'             => 'typography',
                    'title'            => esc_html__( 'Body', 'bustro-toolkit' ),
                    'output'           => 'body',
                    'line_height_unit' => 'em',
                    'dependency'       => [
                        'body_typo_types', '==', 'custom-font',
                    ],
                ],
                [
                    'id'      => 'heading_typo_type',
                    'type'    => 'button_set',
                    'title'   => esc_html__( 'Heading Typography', 'bustro-toolkit' ),
                    'options' => [
                        'default-font' => esc_html__( 'Default', 'bustro-toolkit' ),
                        'custom-font'  => esc_html__( 'Custom', 'bustro-toolkit' ),
                    ],
                    'default' => 'default-font',
                ],
                [
                    'id'               => 'heading1_typo',
                    'type'             => 'typography',
                    'title'            => esc_html__( 'Heading 1', 'bustro-toolkit' ),
                    'output'           => 'h1',
                    'line_height_unit' => 'em',
                    'dependency'       => [
                        'heading_typo_type', '==', 'custom-font',
                    ],
                ],
                [
                    'id'               => 'heading2_typo',
                    'type'             => 'typography',
                    'title'            => esc_html__( 'Heading 2', 'bustro-toolkit' ),
                    'output'           => 'h2',
                    'line_height_unit' => 'em',
                    'dependency'       => [
                        'heading_typo_type', '==', 'custom-font',
                    ],
                ],
                [
                    'id'               => 'heading3_typo',
                    'type'             => 'typography',
                    'title'            => esc_html__( 'Heading 3', 'bustro-toolkit' ),
                    'output'           => 'h3',
                    'line_height_unit' => 'em',
                    'dependency'       => [
                        'heading_typo_type', '==', 'custom-font',
                    ],
                ],
                [
                    'id'               => 'heading4_typo',
                    'type'             => 'typography',
                    'title'            => esc_html__( 'Heading 4', 'bustro-toolkit' ),
                    'output'           => 'h4',
                    'line_height_unit' => 'em',
                    'dependency'       => [
                        'heading_typo_type', '==', 'custom-font',
                    ],
                ],
                [
                    'id'               => 'heading5_typo',
                    'type'             => 'typography',
                    'title'            => esc_html__( 'Heading 5', 'bustro-toolkit' ),
                    'output'           => 'h5',
                    'line_height_unit' => 'em',
                    'dependency'       => [
                        'heading_typo_type', '==', 'custom-font',
                    ],
                ],
                [
                    'id'               => 'heading6_typo',
                    'type'             => 'typography',
                    'title'            => esc_html__( 'Heading 6', 'bustro-toolkit' ),
                    'output'           => 'h6',
                    'line_height_unit' => 'em',
                    'dependency'       => [
                        'heading_typo_type', '==', 'custom-font',
                    ],
                ],
            ],
        ] );
    }

    /**
     * Custom Script Options
     */
    public function custom_scrips_section() {
        CSF::createSection( $this->options_prefix, [
            'title'  => esc_html__( 'Custom Scripts', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Custom Scripts', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'custom_header_scripts',
                    'type'     => 'code_editor',
                    'title'    => esc_html__( 'Js Code(Head)', 'bustro-toolkit' ),
                    'settings' => [
                        'theme' => 'mbo',
                        'mode'  => 'javascript',
                    ],
                    'subtitle' => esc_html__( 'Add your custom js code here. Must Be type without script tag and valid code, It will insert the code to wp_head hook.
                    ', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'custom_footer_scripts',
                    'type'     => 'code_editor',
                    'title'    => esc_html__( 'Js Code(Footer)', 'bustro-toolkit' ),
                    'settings' => [
                        'theme' => 'mbo',
                        'mode'  => 'javascript',
                    ],
                    'subtitle' => esc_html__( 'Add your custom js code here. Must Be type without script tag and valid code, It will insert the code to wp_footer hook.
                    ', 'bustro-toolkit' ),
                ],
                [
                    'type'    => 'submessage',
                    'style'   => 'info',
                    'content' => esc_html__( 'You Can add also custom css in Appearance>Customize>Additional CSS', 'bustro-toolkit' ),
                ],
            ],
        ] );
    }

    /**
     * Backup Options
     */
    public function backup_section() {
        CSF::createSection( $this->options_prefix, [
            'title'  => esc_html__( 'Backup', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Backup', 'bustro-toolkit' ),
                ],
                [
                    'type' => 'backup',
                ],
            ],
        ] );
    }
}

Bustro_Theme_Options::instance()->initialize();