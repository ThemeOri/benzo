<?php
namespace BustroToolkit\ElementorAddon\Widgets;

use BustroToolkit\ElementorAddon\Helper\Bustro_Post_Templates;
use BustroToolkit\ElementorAddon\Helper\Bustro_Query_Builder;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

defined( 'ABSPATH' ) || exit;

class Bustro_Post_Slider extends Widget_Base {

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'bustro-post-slider';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Bustro Post Slider', 'bustro-toolkit' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-post-slider';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return ['bustro_elements'];
    }

    /**
     * Get widget keywords.
     *
     * Retrieve the list of keywords the widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return ['Bustro', 'post', 'news', 'slider', 'blog'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'widget_content',
            [
                'label' => esc_html__( 'General', 'bustro-toolkit' ),
            ]
        );

        $this->add_control(
            'post_layout',
            [
                'label'   => esc_html__( 'Layout', 'bustro-toolkit' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'normal-layout'     => esc_html__( 'Normal Layout', 'bustro-toolkit' ),
                    'image-background'  => esc_html__( 'Image Background', 'bustro-toolkit' ),
                    'image-hover-bg'    => esc_html__( 'Image Hover Background', 'bustro-toolkit' ),
                    'image-left'        => esc_html__( 'Image left', 'bustro-toolkit' ),
                    'image-right'       => esc_html__( 'Image Right', 'bustro-toolkit' ),
                    'image-left-boxed'  => esc_html__( 'Image Left Boxed', 'bustro-toolkit' ),
                    'image-right-boxed' => esc_html__( 'Image Right Boxed', 'bustro-toolkit' ),
                ],
                'default' => 'normal-layout',
            ]
        );

        $this->add_control(
            'meta_design',
            [
                'label'   => esc_html__( 'Meta Design', 'bustro-toolkit' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'meta-design-one'   => esc_html__( 'Design One', 'bustro-toolkit' ),
                    'meta-design-two'   => esc_html__( 'Design Two', 'bustro-toolkit' ),
                    'meta-design-three' => esc_html__( 'Design Three', 'bustro-toolkit' ),
                ],
                'default' => 'meta-design-one',
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label'       => esc_html__( 'Title HTML Tag', 'bustro-toolkit' ),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,
                'options'     => [
                    'h3' => [
                        'title' => esc_html__( 'H3', 'bustro-toolkit' ),
                        'icon'  => 'eicon-editor-h3',
                    ],
                    'h4' => [
                        'title' => esc_html__( 'H4', 'bustro-toolkit' ),
                        'icon'  => 'eicon-editor-h4',
                    ],
                    'h5' => [
                        'title' => esc_html__( 'H5', 'bustro-toolkit' ),
                        'icon'  => 'eicon-editor-h5',
                    ],
                    'h6' => [
                        'title' => esc_html__( 'H6', 'bustro-toolkit' ),
                        'icon'  => 'eicon-editor-h6',
                    ],
                ],
                'default'     => 'h4',
                'toggle'      => false,
            ]
        );

        $this->add_control(
            'title_word',
            [
                'label'   => esc_html__( 'Title Word', 'bustro-toolkit' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 10,
            ]
        );

        $this->add_control(
            'show_excerpt',
            [
                'label'        => esc_html__( 'Show Excerpt', 'bustro-toolkit' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'bustro-toolkit' ),
                'label_off'    => esc_html__( 'Hide', 'bustro-toolkit' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'separator'    => 'before',
            ]
        );

        $this->add_control(
            'excerpt_word',
            [
                'label'     => esc_html__( 'Excerpt Word', 'bustro-toolkit' ),
                'type'      => Controls_Manager::NUMBER,
                'default'   => 25,
                'condition' => [
                    'show_excerpt' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_category',
            [
                'label'        => esc_html__( 'Show Category', 'bustro-toolkit' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'bustro-toolkit' ),
                'label_off'    => esc_html__( 'Hide', 'bustro-toolkit' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_author',
            [
                'label'        => esc_html__( 'Show Author', 'bustro-toolkit' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'bustro-toolkit' ),
                'label_off'    => esc_html__( 'Hide', 'bustro-toolkit' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_date',
            [
                'label'        => esc_html__( 'Show Date', 'bustro-toolkit' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'bustro-toolkit' ),
                'label_off'    => esc_html__( 'Hide', 'bustro-toolkit' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'show_read_more',
            [
                'label'        => esc_html__( 'Show Read More', 'bustro-toolkit' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'bustro-toolkit' ),
                'label_off'    => esc_html__( 'Hide', 'bustro-toolkit' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );

        $this->add_control(
            'read_more_text',
            [
                'label'     => esc_html__( 'Button Text', 'bustro-toolkit' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__( 'Read More', 'bustro-toolkit' ),
                'condition' => [
                    'show_read_more' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name'    => 'thumbnail',
                'default' => 'medium_large',
                'exclude' => [
                    'custom',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'slider_content',
            [
                'label' => esc_html__( 'Additional Options', 'bustro-toolkit' ),
            ]
        );

        $this->add_control(
            'column_heading',
            [
                'label'     => esc_html__( 'Items', 'bustro-toolkit' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'desktop_column',
            [
                'label'   => esc_html__( 'Desktop', 'bustro-toolkit' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__( 'One', 'bustro-toolkit' ),
                    '2' => esc_html__( 'Two', 'bustro-toolkit' ),
                    '3' => esc_html__( 'Three', 'bustro-toolkit' ),
                    '4' => esc_html__( 'Four', 'bustro-toolkit' ),
                ],
                'default' => '3',
            ]
        );

        $this->add_control(
            'tab_column',
            [
                'label'   => esc_html__( 'Tab', 'bustro-toolkit' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__( 'One', 'bustro-toolkit' ),
                    '2' => esc_html__( 'Two', 'bustro-toolkit' ),
                    '3' => esc_html__( 'Three', 'bustro-toolkit' ),
                    '4' => esc_html__( 'Four', 'bustro-toolkit' ),
                ],
                'default' => '2',
            ]
        );

        $this->add_control(
            'mobile_column',
            [
                'label'   => esc_html__( 'Mobile', 'bustro-toolkit' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__( 'One', 'bustro-toolkit' ),
                    '2' => esc_html__( 'Two', 'bustro-toolkit' ),
                    '3' => esc_html__( 'Three', 'bustro-toolkit' ),
                    '4' => esc_html__( 'Four', 'bustro-toolkit' ),
                ],
                'default' => '1',
            ]
        );

        $this->add_control(
            'hr_arrow', [
                'type' => Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'arrow',
            [
                'label'   => esc_html__( 'Arrow?', 'bustro-toolkit' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',
                'options' => [
                    'true'  => esc_html__( 'Yes', 'bustro-toolkit' ),
                    'false' => esc_html__( 'No', 'bustro-toolkit' ),
                ],
            ]
        );

        $this->add_control(
            'dots',
            [
                'label'   => esc_html__( 'Dots?', 'bustro-toolkit' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'false',
                'options' => [
                    'true'  => esc_html__( 'Yes', 'bustro-toolkit' ),
                    'false' => esc_html__( 'No', 'bustro-toolkit' ),
                ],
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label'   => esc_html__( 'Autoplay?', 'bustro-toolkit' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'true',
                'options' => [
                    'true'  => esc_html__( 'Yes', 'bustro-toolkit' ),
                    'false' => esc_html__( 'No', 'bustro-toolkit' ),
                ],
            ]

        );

        $this->add_control(
            'autoplay_time',
            [
                'label'     => esc_html__( 'Autoplay Time', 'bustro-toolkit' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => '5000',
                'condition' => [
                    'autoplay' => 'true',
                ],
                'options'   => [
                    '1000'  => esc_html__( '1s', 'bustro-toolkit' ),
                    '2000'  => esc_html__( '2s', 'bustro-toolkit' ),
                    '3000'  => esc_html__( '3s', 'bustro-toolkit' ),
                    '4000'  => esc_html__( '4s', 'bustro-toolkit' ),
                    '5000'  => esc_html__( '5s', 'bustro-toolkit' ),
                    '6000'  => esc_html__( '6s', 'bustro-toolkit' ),
                    '7000'  => esc_html__( '7s', 'bustro-toolkit' ),
                    '8000'  => esc_html__( '8s', 'bustro-toolkit' ),
                    '9000'  => esc_html__( '9s', 'bustro-toolkit' ),
                    '10000' => esc_html__( '10s', 'bustro-toolkit' ),
                    '11000' => esc_html__( '11s', 'bustro-toolkit' ),
                    '12000' => esc_html__( '12s', 'bustro-toolkit' ),
                    '13000' => esc_html__( '13s', 'bustro-toolkit' ),
                    '14000' => esc_html__( '14s', 'bustro-toolkit' ),
                    '15000' => esc_html__( '15s', 'bustro-toolkit' ),
                ],
            ]
        );

        $this->end_controls_section();

        Bustro_Query_Builder::render_loop_options( $this, ['post_type' => 'post'] );

        $this->start_controls_section(
            'post_item_style',
            [
                'label' => esc_html__( 'Post Item', 'bustro-toolkit' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'post_item_padding',
            [
                'label'      => esc_html__( 'Margin', 'bustro-toolkit' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .bustro-post-boxes .bustro-post-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'post_item_margin',
            [
                'label'      => esc_html__( 'Padding', 'bustro-toolkit' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .bustro-post-boxes .bustro-post-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'post_item_bg',
            [
                'label'     => esc_html__( 'Background Color', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bustro-post-boxes .bustro-post-box' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'post_item_border',
                'selector' => '{{WRAPPER}} .bustro-post-boxes .bustro-post-box',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'post_media_style',
            [
                'label' => esc_html__( 'Post Media', 'bustro-toolkit' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'post_media_margin',
            [
                'label'      => esc_html__( 'Margin', 'bustro-toolkit' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .bustro-post-box .post-media' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'post_media_width',
            [
                'label'      => esc_html__( 'Width', 'bustro-toolkit' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .bustro-post-box .post-media' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition'  => [
                    'post_layout!' => 'image-hover-bg',
                ],
            ]
        );

        $this->add_responsive_control(
            'post_media_height',
            [
                'label'      => esc_html__( 'Height', 'bustro-toolkit' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range'      => [
                    '%'  => [
                        'min' => 1,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .bustro-post-box .post-media' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'condition'  => [
                    'post_layout!' => 'image-hover-bg',
                ],
                'separator'  => 'after',
            ]
        );

        $this->add_control(
            'post_media_overly',
            [
                'label'      => esc_html__( 'Overly Color', 'bustro-toolkit' ),
                'type'       => Controls_Manager::COLOR,
                'selectors'  => [
                    '{{WRAPPER}} .bustro-post-boxes .bustro-post-box .post-media::before' => 'background: {{VALUE}}',
                ],
                'conditions' => [
                    'relation' => 'or',
                    'terms'    => [
                        [
                            'name'     => 'post_layout',
                            'operator' => '==',
                            'value'    => 'image-background',
                        ],
                        [
                            'name'     => 'post_layout',
                            'operator' => '==',
                            'value'    => 'image-hover-bg',
                        ],
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'post_media_overly_opacity',
            [
                'label'      => esc_html__( 'opacity', 'bustro-toolkit' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0.1,
                        'max'  => 1,
                        'step' => 0.1,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .bustro-post-boxes .bustro-post-box.image-background .post-media::before'     => 'opacity: {{SIZE}};',
                    '{{WRAPPER}} .bustro-post-boxes .bustro-post-box.image-hover-bg:hover .post-media::before' => 'opacity: {{SIZE}};',
                ],
                'conditions' => [
                    'relation' => 'or',
                    'terms'    => [
                        [
                            'name'     => 'post_layout',
                            'operator' => '==',
                            'value'    => 'image-background',
                        ],
                        [
                            'name'     => 'post_layout',
                            'operator' => '==',
                            'value'    => 'image-hover-bg',
                        ],
                    ],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'post_content_style',
            [
                'label' => esc_html__( 'Post Content', 'bustro-toolkit' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'post_content_bg',
            [
                'label'     => esc_html__( 'Background Color', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bustro-post-boxes .bustro-post-box .post-content' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'post_content_border',
                'selector' => '{{WRAPPER}} .bustro-post-boxes .bustro-post-box .post-content',
            ]
        );

        $this->add_responsive_control(
            'post_content_padding',
            [
                'label'      => esc_html__( 'Margin', 'bustro-toolkit' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .bustro-post-boxes .bustro-post-box .post-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'post_content_margin',
            [
                'label'      => esc_html__( 'Padding', 'bustro-toolkit' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .bustro-post-boxes .bustro-post-box .post-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_heading',
            [
                'label'     => esc_html__( 'Title', 'bustro-toolkit' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__( 'Color', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bustro-post-box .post-content .post-title a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'title_hover_color',
            [
                'label'     => esc_html__( 'Color(Hover)', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bustro-post-box .post-content .post-title:hover a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .bustro-post-box .post-content .post-title',
            ]
        );

        $this->add_control(
            'excerpt_heading',
            [
                'label'     => esc_html__( 'Excerpt', 'bustro-toolkit' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_excerpt' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'excerpt_color',
            [
                'label'     => esc_html__( 'Color', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bustro-post-box .post-content p' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'show_excerpt' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'excerpt_typography',
                'selector'  => '{{WRAPPER}} .bustro-post-box .post-content p',
                'condition' => [
                    'show_excerpt' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'meta_heading',
            [
                'label'     => esc_html__( 'Post Meta', 'bustro-toolkit' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'meta_3_color',
            [
                'label'     => esc_html__( 'Color', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bustro-post-box .post-content .post-meta'   => 'color: {{VALUE}}',
                    '{{WRAPPER}} .bustro-post-box .post-content .post-meta a' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'meta_design' => 'meta-design-three',
                ],
            ]
        );

        $this->add_control(
            'meta_3_cat_color',
            [
                'label'     => esc_html__( 'Categories Color', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bustro-post-box .post-content .post-meta .post-categories a' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'meta_design' => 'meta-design-three',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'meta_3_typography',
                'selector'  => '{{WRAPPER}} .bustro-post-box .post-content .post-meta',
                'condition' => [
                    'meta_design' => 'meta-design-three',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'     => esc_html__( 'Categories Typography', 'bustro-toolkit' ),
                'name'      => 'category_typography',
                'selector'  => '{{WRAPPER}} .bustro-post-box.meta-design-one .post-categories a, {{WRAPPER}} .bustro-post-box.meta-design-two .post-categories a',
                'condition' => [
                    'meta_design!' => 'meta-design-three',
                ],
            ]
        );

        $this->add_control(
            'category_color',
            [
                'label'     => esc_html__( 'Categories Color', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bustro-post-box.meta-design-one .post-categories a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .bustro-post-box.meta-design-two .post-categories a' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'meta_design!' => 'meta-design-three',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'     => esc_html__( 'Author Typography', 'bustro-toolkit' ),
                'name'      => 'author_typography',
                'selector'  => '{{WRAPPER}} .bustro-post-box .post-content .post-author-date .author-name',
                'condition' => [
                    'meta_design!' => 'meta-design-three',
                ],
            ]
        );

        $this->add_control(
            'author_color',
            [
                'label'     => esc_html__( 'Author Color', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bustro-post-box .post-content .post-author-date .author-name' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'meta_design!' => 'meta-design-three',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'label'     => esc_html__( 'Date Typography', 'bustro-toolkit' ),
                'name'      => 'date_typography',
                'selector'  => '{{WRAPPER}} .bustro-post-box .post-content .post-author-date .post-date',
                'condition' => [
                    'meta_design!' => 'meta-design-three',
                ],
            ]
        );

        $this->add_control(
            'date_color',
            [
                'label'     => esc_html__( 'Date Color', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bustro-post-box .post-content .post-author-date .post-date' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'meta_design!' => 'meta-design-three',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'slider_arrow_style',
            [
                'label'     => esc_html__( 'Arrows', 'bustro-toolkit' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'arrow' => 'true',
                ],
            ]
        );

        $this->add_control(
            'arrow_position',
            [
                'label'   => esc_html__( 'Position', 'bustro-toolkit' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'arrows-left-top'     => esc_html__( 'Left Top', 'bustro-toolkit' ),
                    'arrows-right-top'    => esc_html__( 'Right Top', 'bustro-toolkit' ),
                    'arrows-left-bottom'  => esc_html__( 'Left Bottom', 'bustro-toolkit' ),
                    'arrows-right-bottom' => esc_html__( 'Right Bottom', 'bustro-toolkit' ),
                ],
                'default' => 'arrows-left-top',
            ]
        );

        $this->add_control(
            'arrow_color',
            [
                'label'     => esc_html__( 'Arrow color', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-slider-arrows .slick-arrow' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'arrow_bg',
            [
                'label'     => esc_html__( 'Arrow Background', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-slider-arrows .slick-arrow' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'arrow_divider',
            [
                'label'     => esc_html__( 'Arrow Divider', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-slider-arrows::before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'slider_dots_style',
            [
                'label'     => esc_html__( 'Dots', 'bustro-toolkit' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'dots' => 'true',
                ],
            ]
        );

        $this->add_control(
            'dots_position',
            [
                'label'   => esc_html__( 'Position', 'bustro-toolkit' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'dots-left-top'      => esc_html__( 'Left Top', 'bustro-toolkit' ),
                    'dots-right-top'    => esc_html__( 'Right Top', 'bustro-toolkit' ),
                    'dots-center-top'    => esc_html__( 'Center Top', 'bustro-toolkit' ),
                    'dots-left-bottom'   => esc_html__( 'Left Bottom', 'bustro-toolkit' ),
                    'dots-right-bottom'  => esc_html__( 'Right Bottom', 'bustro-toolkit' ),
                    'dots-center-bottom' => esc_html__( 'Center Bottom', 'bustro-toolkit' ),
                ],
                'default' => 'dots-right-top',
            ]
        );

        $this->add_control(
            'dots_color',
            [
                'label'     => esc_html__( 'Color', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-slider-dots .slick-dots li' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'dots_active_color',
            [
                'label'     => esc_html__( 'Color(Active)', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-slider-dots .slick-dots li.slick-active' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings                    = $this->get_settings_for_display();
        $settings['navigation_type'] = 'none';
        Bustro_Post_Templates::render_post_boxes( $settings, true );
    }
}