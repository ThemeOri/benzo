<?php
namespace BustroToolkit\Helper;

use BustroToolkit\ElementorAddon\Helper\Bustro_Post_Templates;
use WP_Query;

defined( 'ABSPATH' ) || exit;

/**
 * Bustro Toolkit Helper
 */

if ( ! class_exists( 'Bustro_Ajax' ) ) {

    class Bustro_Ajax {

        /**
         * Class Constructor
         */
        public function __construct() {
            add_action( 'wp_ajax_bustro_load_more_ajax', [$this, 'bustro_load_more_ajax'] );
            add_action( 'wp_ajax_nopriv_bustro_load_more_ajax', [$this, 'bustro_load_more_ajax'] );
            add_action( 'wp_ajax_bustro_ajax_post_tab', [$this, 'bustro_ajax_post_tab'] );
            add_action( 'wp_ajax_nopriv_bustro_ajax_post_tab', [$this, 'bustro_ajax_post_tab'] );
        }

        /**
         * Load More Button AJAX Init
         */
        public function bustro_load_more_ajax() {
            $nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( $_REQUEST['nonce'] ) : 0;

            if ( ! wp_verify_nonce( $nonce, 'bustro-load-more' ) ): ?>
                <div class="ajax-error-msg col-12">
                    <p><?php esc_html_e( 'Something went wrong...', 'bustro-toolkit' )?></p>
                </div>
            <?php else:
                $args    = $_POST['data']['query'];
                $options = $_POST['data']['options'];
                $query   = new WP_Query( $args );

                if ( array_key_exists( 'column', $options ) ):
                    if ( $query->have_posts() ):
                        while ( $query->have_posts() ): $query->the_post();?>
                            <div class="<?php echo esc_attr( implode( ' ', $options['column'] ) ) ?>">
                                <?php Bustro_Post_Templates::render_post_box( $options );?>
                            </div>
                        <?php endwhile;
                    endif;
                    wp_reset_query();
                else:
                    switch ( $options['masonry_layout'] ) {
                        case 'layout-one':
                        case 'layout-six':
                            Bustro_Post_Templates::masonry_layout_one( $query, $options );
                            break;
                        case 'layout-two':
                            Bustro_Post_Templates::masonry_layout_two( $query, $options );
                            break;
                        case 'layout-three':
                            Bustro_Post_Templates::masonry_layout_three( $query, $options );
                            break;
                        case 'layout-four':
                            Bustro_Post_Templates::masonry_layout_four( $query, $options );
                            break;
                        case 'layout-five':
                            Bustro_Post_Templates::masonry_layout_five( $query, $options );
                            break;
                        case 'layout-seven':
                            Bustro_Post_Templates::masonry_layout_seven( $query, $options );
                            break;
                    }
                endif;
            endif;

            wp_die();
        }

        /**
         * AJAX Post Tab
         */
        public function bustro_ajax_post_tab() {
            $nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( $_REQUEST['nonce'] ) : 0;

            if ( ! wp_verify_nonce( $nonce, 'bustro-post-tab' ) ): ?>
                <div class="ajax-error-msg col-12">
                    <p><?php esc_html_e( 'Something went wrong...', 'bustro-toolkit' )?></p>
                </div>
            <?php else:
                $args   = $_POST['data']['query'];
                $cat_id = $_POST['cat_id'];
                $options = $_POST['data']['options'];

                if ( 'all' !== $cat_id ) {
                    unset( $args['category_name'] );
                    $args['category__in'] = $cat_id;
                }

                $query   = new WP_Query( $args );
                Bustro_Post_Templates::render_post_tab( $query, $options );
            endif;

            wp_die();
        }
    }

    new Bustro_Ajax();
}