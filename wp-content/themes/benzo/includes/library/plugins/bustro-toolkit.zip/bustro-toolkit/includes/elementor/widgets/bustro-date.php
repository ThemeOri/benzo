<?php
namespace BustroToolkit\ElementorAddon\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

defined( 'ABSPATH' ) || exit;

class Bustro_Date extends Widget_Base {

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'bustro-date';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Bustro Current Date', 'bustro-toolkit' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-date';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return ['bustro_elements'];
    }

    /**
     * Get widget keywords.
     *
     * Retrieve the list of keywords the widget belongs to.
     *
     * @since 1.0.0
     * @access public
     *
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return ['Bustro', 'Toolkit', 'Date', 'Current'];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls() {

        $this->start_controls_section(
            'widget_content',
            [
                'label' => esc_html__( 'General', 'bustro-toolkit' ),
            ]
        );

        $this->add_control(
            'date_format_select',
            [
                'label'   => esc_html__( 'Date Format', 'bustro-toolkit' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'default'          => esc_html__( 'Default', 'bustro-toolkit' ),
                    'wordpress_format' => esc_html__( 'Wordpress Format', 'bustro-toolkit' ),
                    'custom'           => esc_html__( 'Custom', 'bustro-toolkit' ),
                ],
                'default' => 'default',
            ]
        );

        $this->add_control(
            'date_format_custom',
            [
                'label'       => esc_html__( 'Custom Date Format', 'bustro-toolkit' ),
                'type'        => Controls_Manager::TEXT,
                'condition'   => ['date_format_select' => 'custom'],
                'description' => esc_html__( 'Set your date format, about this, please refer to the ', 'bustro-toolkit' )
                . sprintf(
                    ' <a href="%1$s" target="_blank">%2$s</a>',
                    'https://wordpress.org/support/article/formatting-date-and-time/',
                    esc_html__( 'Wordpress.org', 'bustro-toolkit' )
                ),
                'label_block' => true,
                'default'     => 'F j, Y',
            ]
        );

        $this->add_control(
            'time_zone',
            [
                'label'   => esc_html__( 'Time Zone', 'bustro-toolkit' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'UTC'                  => esc_html__( 'Default', 'bustro-toolkit' ),
                    'Pacific/Midway'       => esc_html__( '(GMT-11:00) Midway Island', 'bustro-toolkit' ),
                    'US/Samoa'             => esc_html__( '(GMT-11:00) Samoa', 'bustro-toolkit' ),
                    'US/Hawaii'            => esc_html__( '(GMT-10:00) Hawaii', 'bustro-toolkit' ),
                    'US/Alaska'            => esc_html__( '(GMT-09:00) Alaska', 'bustro-toolkit' ),
                    'US/Pacific'           => esc_html__( '(GMT-08:00) Pacific Time (US &amp; Canada)', 'bustro-toolkit' ),
                    'America/Tijuana'      => esc_html__( '(GMT-08:00) Tijuana', 'bustro-toolkit' ),
                    'US/Arizona'           => esc_html__( '(GMT-07:00) Arizona', 'bustro-toolkit' ),
                    'US/Mountain'          => esc_html__( '(GMT-07:00) Mountain Time (US &amp; Canada)', 'bustro-toolkit' ),
                    'America/Chihuahua'    => esc_html__( '(GMT-07:00) Chihuahua', 'bustro-toolkit' ),
                    'America/Mazatlan'     => esc_html__( '(GMT-07:00) Mazatlan', 'bustro-toolkit' ),
                    'America/Mexico_City'  => esc_html__( '(GMT-06:00) Mexico City', 'bustro-toolkit' ),
                    'America/Monterrey'    => esc_html__( '(GMT-06:00) Monterrey', 'bustro-toolkit' ),
                    'Canada/Saskatchewan'  => esc_html__( '(GMT-06:00) Saskatchewan', 'bustro-toolkit' ),
                    'US/Central'           => esc_html__( '(GMT-06:00) Central Time (US &amp; Canada)', 'bustro-toolkit' ),
                    'US/Eastern'           => esc_html__( '(GMT-05:00) Eastern Time (US &amp; Canada)', 'bustro-toolkit' ),
                    'US/East-Indiana'      => esc_html__( '(GMT-05:00) Indiana (East)', 'bustro-toolkit' ),
                    'America/Bogota'       => esc_html__( '(GMT-05:00) Bogota', 'bustro-toolkit' ),
                    'America/Lima'         => esc_html__( '(GMT-05:00) Lima', 'bustro-toolkit' ),
                    'America/Caracas'      => esc_html__( '(GMT-04:30) Caracas', 'bustro-toolkit' ),
                    'Canada/Atlantic'      => esc_html__( '(GMT-04:00) Atlantic Time (Canada)', 'bustro-toolkit' ),
                    'America/La_Paz'       => esc_html__( '(GMT-04:00) La Paz', 'bustro-toolkit' ),
                    'America/Santiago'     => esc_html__( '(GMT-04:00) Santiago', 'bustro-toolkit' ),
                    'Canada/Newfoundland'  => esc_html__( '(GMT-03:30) Newfoundland', 'bustro-toolkit' ),
                    'America/Buenos_Aires' => esc_html__( '(GMT-03:00) Buenos Aires', 'bustro-toolkit' ),
                    'Greenland'            => esc_html__( '(GMT-03:00) Greenland', 'bustro-toolkit' ),
                    'Atlantic/Stanley'     => esc_html__( '(GMT-02:00) Stanley', 'bustro-toolkit' ),
                    'Atlantic/Azores'      => esc_html__( '(GMT-01:00) Azores', 'bustro-toolkit' ),
                    'Atlantic/Cape_Verde'  => esc_html__( '(GMT-01:00) Cape Verde Is.', 'bustro-toolkit' ),
                    'Africa/Casablanca'    => esc_html__( '(GMT) Casablanca', 'bustro-toolkit' ),
                    'Europe/Dublin'        => esc_html__( '(GMT) Dublin', 'bustro-toolkit' ),
                    'Europe/Lisbon'        => esc_html__( '(GMT) Lisbon', 'bustro-toolkit' ),
                    'Europe/London'        => esc_html__( '(GMT) London', 'bustro-toolkit' ),
                    'Africa/Monrovia'      => esc_html__( '(GMT) Monrovia', 'bustro-toolkit' ),
                    'Europe/Amsterdam'     => esc_html__( '(GMT+01:00) Amsterdam', 'bustro-toolkit' ),
                    'Europe/Belgrade'      => esc_html__( '(GMT+01:00) Belgrade', 'bustro-toolkit' ),
                    'Europe/Berlin'        => esc_html__( '(GMT+01:00) Berlin', 'bustro-toolkit' ),
                    'Europe/Bratislava'    => esc_html__( '(GMT+01:00) Bratislava', 'bustro-toolkit' ),
                    'Europe/Brussels'      => esc_html__( '(GMT+01:00) Brussels', 'bustro-toolkit' ),
                    'Europe/Budapest'      => esc_html__( '(GMT+01:00) Budapest', 'bustro-toolkit' ),
                    'Europe/Copenhagen'    => esc_html__( '(GMT+01:00) Copenhagen', 'bustro-toolkit' ),
                    'Europe/Ljubljana'     => esc_html__( '(GMT+01:00) Ljubljana', 'bustro-toolkit' ),
                    'Europe/Madrid'        => esc_html__( '(GMT+01:00) Madrid', 'bustro-toolkit' ),
                    'Europe/Paris'         => esc_html__( '(GMT+01:00) Paris', 'bustro-toolkit' ),
                    'Europe/Prague'        => esc_html__( '(GMT+01:00) Prague', 'bustro-toolkit' ),
                    'Europe/Rome'          => esc_html__( '(GMT+01:00) Rome', 'bustro-toolkit' ),
                    'Europe/Sarajevo'      => esc_html__( '(GMT+01:00) Sarajevo', 'bustro-toolkit' ),
                    'Europe/Skopje'        => esc_html__( '(GMT+01:00) Skopje', 'bustro-toolkit' ),
                    'Europe/Stockholm'     => esc_html__( '(GMT+01:00) Stockholm', 'bustro-toolkit' ),
                    'Europe/Vienna'        => esc_html__( '(GMT+01:00) Vienna', 'bustro-toolkit' ),
                    'Europe/Warsaw'        => esc_html__( '(GMT+01:00) Warsaw', 'bustro-toolkit' ),
                    'Europe/Zagreb'        => esc_html__( '(GMT+01:00) Zagreb', 'bustro-toolkit' ),
                    'Europe/Athens'        => esc_html__( '(GMT+02:00) Athens', 'bustro-toolkit' ),
                    'Europe/Bucharest'     => esc_html__( '(GMT+02:00) Bucharest', 'bustro-toolkit' ),
                    'Africa/Cairo'         => esc_html__( '(GMT+02:00) Cairo', 'bustro-toolkit' ),
                    'Africa/Harare'        => esc_html__( '(GMT+02:00) Harare', 'bustro-toolkit' ),
                    'Europe/Helsinki'      => esc_html__( '(GMT+02:00) Helsinki', 'bustro-toolkit' ),
                    'Europe/Istanbul'      => esc_html__( '(GMT+02:00) Istanbul', 'bustro-toolkit' ),
                    'Asia/Jerusalem'       => esc_html__( '(GMT+02:00) Jerusalem', 'bustro-toolkit' ),
                    'Europe/Kiev'          => esc_html__( '(GMT+02:00) Kyiv', 'bustro-toolkit' ),
                    'Europe/Minsk'         => esc_html__( '(GMT+02:00) Minsk', 'bustro-toolkit' ),
                    'Europe/Riga'          => esc_html__( '(GMT+02:00) Riga', 'bustro-toolkit' ),
                    'Europe/Sofia'         => esc_html__( '(GMT+02:00) Sofia', 'bustro-toolkit' ),
                    'Europe/Tallinn'       => esc_html__( '(GMT+02:00) Tallinn', 'bustro-toolkit' ),
                    'Europe/Vilnius'       => esc_html__( '(GMT+02:00) Vilnius', 'bustro-toolkit' ),
                    'Asia/Baghdad'         => esc_html__( '(GMT+03:00) Baghdad', 'bustro-toolkit' ),
                    'Asia/Kuwait'          => esc_html__( '(GMT+03:00) Kuwait', 'bustro-toolkit' ),
                    'Africa/Nairobi'       => esc_html__( '(GMT+03:00) Nairobi', 'bustro-toolkit' ),
                    'Asia/Riyadh'          => esc_html__( '(GMT+03:00) Riyadh', 'bustro-toolkit' ),
                    'Europe/Moscow'        => esc_html__( '(GMT+03:00) Moscow', 'bustro-toolkit' ),
                    'Asia/Tehran'          => esc_html__( '(GMT+03:30) Tehran', 'bustro-toolkit' ),
                    'Asia/Baku'            => esc_html__( '(GMT+04:00) Baku', 'bustro-toolkit' ),
                    'Europe/Volgograd'     => esc_html__( '(GMT+04:00) Volgograd', 'bustro-toolkit' ),
                    'Asia/Muscat'          => esc_html__( '(GMT+04:00) Muscat', 'bustro-toolkit' ),
                    'Asia/Tbilisi'         => esc_html__( '(GMT+04:00) Tbilisi', 'bustro-toolkit' ),
                    'Asia/Yerevan'         => esc_html__( '(GMT+04:00) Yerevan', 'bustro-toolkit' ),
                    'Asia/Kabul'           => esc_html__( '(GMT+04:30) Kabul', 'bustro-toolkit' ),
                    'Asia/Karachi'         => esc_html__( '(GMT+05:00) Karachi', 'bustro-toolkit' ),
                    'Asia/Tashkent'        => esc_html__( '(GMT+05:00) Tashkent', 'bustro-toolkit' ),
                    'Asia/Kolkata'         => esc_html__( '(GMT+05:30) Kolkata', 'bustro-toolkit' ),
                    'Asia/Kathmandu'       => esc_html__( '(GMT+05:45) Kathmandu', 'bustro-toolkit' ),
                    'Asia/Yekaterinburg'   => esc_html__( '(GMT+06:00) Ekaterinburg', 'bustro-toolkit' ),
                    'Asia/Almaty'          => esc_html__( '(GMT+06:00) Almaty', 'bustro-toolkit' ),
                    'Asia/Dhaka'           => esc_html__( '(GMT+06:00) Dhaka', 'bustro-toolkit' ),
                    'Asia/Novosibirsk'     => esc_html__( '(GMT+07:00) Novosibirsk', 'bustro-toolkit' ),
                    'Asia/Bangkok'         => esc_html__( '(GMT+07:00) Bangkok', 'bustro-toolkit' ),
                    'Asia/Jakarta'         => esc_html__( '(GMT+07:00) Jakarta', 'bustro-toolkit' ),
                    'Asia/Krasnoyarsk'     => esc_html__( '(GMT+08:00) Krasnoyarsk', 'bustro-toolkit' ),
                    'Asia/Chongqing'       => esc_html__( '(GMT+08:00) Chongqing', 'bustro-toolkit' ),
                    'Asia/Hong_Kong'       => esc_html__( '(GMT+08:00) Hong Kong', 'bustro-toolkit' ),
                    'Asia/Kuala_Lumpur'    => esc_html__( '(GMT+08:00) Kuala Lumpur', 'bustro-toolkit' ),
                    'Australia/Perth'      => esc_html__( '(GMT+08:00) Perth', 'bustro-toolkit' ),
                    'Asia/Singapore'       => esc_html__( '(GMT+08:00) Singapore', 'bustro-toolkit' ),
                    'Asia/Taipei'          => esc_html__( '(GMT+08:00) Taipei', 'bustro-toolkit' ),
                    'Asia/Ulaanbaatar'     => esc_html__( '(GMT+08:00) Ulaan Bataar', 'bustro-toolkit' ),
                    'Asia/Urumqi'          => esc_html__( '(GMT+08:00) Urumqi', 'bustro-toolkit' ),
                    'Asia/Irkutsk'         => esc_html__( '(GMT+09:00) Irkutsk', 'bustro-toolkit' ),
                    'Asia/Seoul'           => esc_html__( '(GMT+09:00) Seoul', 'bustro-toolkit' ),
                    'Asia/Tokyo'           => esc_html__( '(GMT+09:00) Tokyo', 'bustro-toolkit' ),
                    'Australia/Adelaide'   => esc_html__( '(GMT+09:30) Adelaide', 'bustro-toolkit' ),
                    'Australia/Darwin'     => esc_html__( '(GMT+09:30) Darwin', 'bustro-toolkit' ),
                    'Asia/Yakutsk'         => esc_html__( '(GMT+10:00) Yakutsk', 'bustro-toolkit' ),
                    'Australia/Brisbane'   => esc_html__( '(GMT+10:00) Brisbane', 'bustro-toolkit' ),
                    'Australia/Canberra'   => esc_html__( '(GMT+10:00) Canberra', 'bustro-toolkit' ),
                    'Pacific/Guam'         => esc_html__( '(GMT+10:00) Guam', 'bustro-toolkit' ),
                    'Australia/Hobart'     => esc_html__( '(GMT+10:00) Hobart', 'bustro-toolkit' ),
                    'Australia/Melbourne'  => esc_html__( '(GMT+10:00) Melbourne', 'bustro-toolkit' ),
                    'Pacific/Port_Moresby' => esc_html__( '(GMT+10:00) Port Moresby', 'bustro-toolkit' ),
                    'Australia/Sydney'     => esc_html__( '(GMT+10:00) Sydney', 'bustro-toolkit' ),
                    'Asia/Vladivostok'     => esc_html__( '(GMT+11:00) Vladivostok', 'bustro-toolkit' ),
                    'Asia/Magadan'         => esc_html__( '(GMT+12:00) Magadan', 'bustro-toolkit' ),
                    'Pacific/Auckland'     => esc_html__( '(GMT+12:00) Auckland', 'bustro-toolkit' ),
                    'Pacific/Fiji'         => esc_html__( '(GMT+12:00) Fiji', 'bustro-toolkit' ),
                ],
                'default' => 'UTC',
            ]
        );

        $this->add_control(
            'date_align',
            [
                'label'       => esc_html__( 'Alignment', 'bustro-toolkit' ),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,
                'toggle'      => true,
                'options'     => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'bustro-toolkit' ),
                        'icon'  => 'eicon-order-start',
                    ],
                    'center'     => [
                        'title' => esc_html__( 'Center', 'bustro-toolkit' ),
                        'icon'  => ' eicon-shrink',
                    ],
                    'right'   => [
                        'title' => esc_html__( 'Right', 'bustro-toolkit' ),
                        'icon'  => 'eicon-order-end',
                    ],
                ],
                'default'     => 'flex-start',
                'selectors'   => [
                    '{{WRAPPER}} .bustro-date' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'date_title_style',
            [
                'label'   => esc_html__( 'Title Style', 'bustro-toolkit' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'text' => esc_html__( 'Text', 'bustro-toolkit' ),
                    'icon' => esc_html__( 'Icon', 'bustro-toolkit' ),
                ],
                'default' => 'date',
            ]
        );

        $this->add_control(
            'title_text',
            [
                'label'     => esc_html__( 'Title Text', 'bustro-toolkit' ),
                'type'      => Controls_Manager::TEXT,
                'default'   => esc_html__( 'Date', 'bustro-toolkit' ),
                'condition' => [
                    'date_title_style' => 'text',
                ],
            ],
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'widget_style',
            [
                'label' => esc_html__( 'Style', 'bustro-toolkit' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'date_color',
            [
                'label'     => esc_html__( 'Color', 'bustro-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bustro-date' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'date_typography',
                'selector' => '{{WRAPPER}} .bustro-date',
            ]
        );
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        $UTC   = new \DateTimeZone( "UTC" );
        $newTZ = new \DateTimeZone( $settings['time_zone'] );

        $date = new \DateTime( 'NOW', $UTC );
        $date->setTimezone( $newTZ );

        switch ( $settings['date_format_select'] ) {
        case 'default':
            $date_html = date_i18n( 'F j, Y' );
            break;

        case 'wordpress_format':
            $date_html = date_i18n( get_option( 'date_format' ) );
            break;

        default:
            $date_html = date_i18n( $settings['date_format_custom'] );
            break;
        }

        ?>

        <div class="bustro-date">
            <?php
                if ( 'icon' === $settings['date_title_style'] ) {
                    echo '<i class="far fa-clock"></i>';
                } else {
                    echo '<span>' . esc_html( $settings['title_text'] ) . '</span>';

                }
                echo esc_html( $date_html );
            ?>
        </div>

        <?php
    }
}