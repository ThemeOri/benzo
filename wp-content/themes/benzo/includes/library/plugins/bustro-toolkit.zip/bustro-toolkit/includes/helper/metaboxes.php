<?php
namespace BustroToolkit\Helper;

use CSF;

defined( 'ABSPATH' ) || exit;

/**
 * Bustro Toolkit Helper
 */

class Bustro_Metaboxes {
    protected static $instance = null;

    private $post_prefix     = 'bustro_post_meta';
    private $page_prefix     = 'bustro_page_meta';
    private $user_prefix     = 'bustro_user_meta';
    private $category_prefix = 'bustro_category_meta';
    private $template_builder_url;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function initialize() {
        if ( ! class_exists( 'CSF' ) ) {
            return;
        }

        $this->template_builder_url = admin_url( 'edit.php?post_type=bustro_template' );

        $this->post_metaboxes();
        $this->page_metaboxes();
        $this->user_metaboxes();
        $this->category_metaboxes();
    }

    public function post_metaboxes() {
        CSF::createMetabox( $this->post_prefix, [
            'title'        => esc_html__( 'Bustro Post Options', 'bustro-toolkit' ),
            'post_type'    => 'post',
            'show_restore' => true,
        ] );

        // General
        CSF::createSection( $this->post_prefix, [
            'title'  => esc_html__( 'General', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'General', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'post_format',
                    'type'    => 'button_set',
                    'title'   => esc_html__( 'Post Format', 'bustro-toolkit' ),
                    'options' => [
                        'standard' => esc_html__( 'Standard', 'bustro-toolkit' ),
                        'gallery'  => esc_html__( 'Gallery', 'bustro-toolkit' ),
                        'video'    => esc_html__( 'Video', 'bustro-toolkit' ),
                        'audio'    => esc_html__( 'Audio', 'bustro-toolkit' ),
                        'quote'    => esc_html__( 'Quote', 'bustro-toolkit' ),
                        'link'     => esc_html__( 'Link', 'bustro-toolkit' ),
                    ],
                    'default' => 'standard',
                ],
                [
                    'id'         => 'post_gallery',
                    'type'       => 'gallery',
                    'title'      => esc_html__( 'Gallery Images', 'bustro-toolkit' ),
                    'desc'       => esc_html__( 'Choose your Gallery Images', 'bustro-toolkit' ),
                    'dependency' => ['post_format', '==', 'gallery'],
                ],
                [
                    'id'         => 'post_video_link',
                    'type'       => 'text',
                    'title'      => esc_html__( 'oEmbed URL', 'bustro-toolkit' ),
                    'dependency' => ['post_format', '==', 'video'],
                ],
                [
                    'id'         => 'post_video_thumb',
                    'type'       => 'media',
                    'library'    => 'image',
                    'title'      => esc_html__( 'Thumbnail', 'bustro-toolkit' ),
                    'desc'       => esc_html__( 'Add video Thumbnail', 'bustro-toolkit' ),
                    'dependency' => ['post_format', '==', 'video'],
                ],
                [
                    'id'         => 'post_audio_link',
                    'type'       => 'text',
                    'title'      => esc_html__( 'oEmbed URL', 'bustro-toolkit' ),
                    'dependency' => ['post_format', '==', 'audio'],
                ],
                [
                    'id'         => 'post_quote_text',
                    'type'       => 'textarea',
                    'title'      => esc_html__( 'Quote', 'bustro-toolkit' ),
                    'dependency' => ['post_format', '==', 'quote'],
                ],
                [
                    'id'         => 'post_quote_author',
                    'type'       => 'text',
                    'title'      => esc_html__( 'Quote Author Name', 'bustro-toolkit' ),
                    'dependency' => ['post_format', '==', 'quote'],
                ],
                [
                    'id'         => 'post_link_url',
                    'type'       => 'text',
                    'title'      => esc_html__( 'Link', 'bustro-toolkit' ),
                    'desc'       => esc_html__( 'Type your link. Example: https://webtend.net', 'bustro-toolkit' ),
                    'dependency' => ['post_format', '==', 'link'],
                ],
                [
                    'id'         => 'post_link_text',
                    'type'       => 'text',
                    'title'      => esc_html__( 'Link Text', 'bustro-toolkit' ),
                    'dependency' => ['post_format', '==', 'link'],
                ],
            ],
        ] );

        // Page Layout
        CSF::createSection( $this->post_prefix, [
            'title'  => esc_html__( 'Layout', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Post Layout', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'post_details_layout',
                    'type'     => 'image_select',
                    'title'    => esc_html__( 'Content Layout', 'bustro-toolkit' ),
                    'options'  => [
                        'default'           => BT_ASSETS . '/img/options/default.jpg',
                        'boxed-layout'      => BT_ASSETS . '/img/options/boxed-layout.jpg',
                        'full-width-layout' => BT_ASSETS . '/img/options/full-width-layout.jpg',
                    ],
                    'default'  => 'default',
                    'desc'     => esc_html__( 'Select Post layout. Full width or In container', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Default Comes From Theme Option', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'post_details_sidebar',
                    'type'     => 'image_select',
                    'title'    => esc_html__( 'Sidebar', 'bustro-toolkit' ),
                    'options'  => [
                        'default'       => BT_ASSETS . '/img/options/default.jpg',
                        'left-sidebar'  => BT_ASSETS . '/img/options/left-sidebar.jpg',
                        'right-sidebar' => BT_ASSETS . '/img/options/right-sidebar.jpg',
                        'no-sidebar'    => BT_ASSETS . '/img/options/no-sidebar.jpg',
                    ],
                    'default'  => 'default',
                    'desc'     => esc_html__( 'Select Page Sidebar. Left sidebar or right sidebar or No sidebar', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Default Comes From Theme Option', 'bustro-toolkit' ),

                ],
                [
                    'id'         => 'content_spacing',
                    'type'       => 'spacing',
                    'title'      => esc_html__( 'Content Spacing', 'bustro-toolkit' ),
                    'show_units' => false,
                    'desc'       => esc_html__( 'Default top: 40px, right: 20px, bottom: 100px, left: 20px', 'bustro-toolkit' ),
                    'output'     => '.content-container',
                ],
            ],
        ] );

        // Header
        CSF::createSection( $this->post_prefix, [
            'title'  => esc_html__( 'Header', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'notice',
                    'style'   => 'info',
                    'content' => esc_html__( 'If you used theme builder for post header then disable default header', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'post_default_header',
                    'type'     => 'button_set',
                    'title'    => esc_html__( 'Default Header', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Enable or Disable post default header. Default comes form theme option', 'bustro-toolkit' ),
                    'options'  => [
                        'default'  => esc_html__( 'Default', 'bustro-toolkit' ),
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default'  => 'default',

                ],
                [
                    'type'       => 'notice',
                    'style'      => 'warning',
                    'content'    => esc_html__( 'You disabled default header. Set your post header form ', 'bustro-toolkit' ) . '<a href="' . esc_url( $this->template_builder_url ) . '">' . esc_html__( 'here', 'bustro-toolkit' ) . '</a>',
                    'dependency' => [
                        'post_default_header', '==', 'disabled',
                    ],
                ],
                [
                    'id'         => 'post_sticky_header',
                    'type'       => 'button_set',
                    'title'      => esc_html__( 'Sticky Header', 'bustro-toolkit' ),
                    'subtitle'   => esc_html__( 'It will stick header at the top when page scrolling. Default comes form theme option', 'bustro-toolkit' ),
                    'options'    => [
                        'default'  => esc_html__( 'Default', 'bustro-toolkit' ),
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default'    => 'default',
                    'dependency' => [
                        'post_default_header', '!=', 'disabled',
                    ],
                ],
            ],
        ] );

        // Page Title
        CSF::createSection( $this->post_prefix, [
            'title'  => esc_html__( 'Page Title', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Page Title', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'post_page_title',
                    'type'    => 'button_set',
                    'title'   => esc_html__( 'Page Title', 'bustro-toolkit' ),
                    'options' => [
                        'default'  => esc_html__( 'Default', 'bustro-toolkit' ),
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default' => 'default',
                ],
                [
                    'id'         => 'post_title_type',
                    'type'       => 'button_set',
                    'title'      => esc_html__( 'Page Title Type', 'bustro-toolkit' ),
                    'options'    => [
                        'default' => esc_html__( 'Default', 'bustro-toolkit' ),
                        'custom'  => esc_html__( 'Custom', 'bustro-toolkit' ),
                    ],
                    'default'    => 'custom',
                    'dependency' => ['post_page_title', '!=', 'disabled'],
                ],
                [
                    'id'         => 'post_custom_title',
                    'type'       => 'text',
                    'title'      => esc_html__( 'Custom Title', 'bustro-toolkit' ),
                    'dependency' => [
                        ['post_page_title', '!=', 'disabled'],
                        ['post_title_type', '==', 'custom'],
                    ],
                    'default'    => esc_html__( 'News Details', 'bustro-toolkit' ),
                ],
                [
                    'id'         => 'post_breadcrumb',
                    'type'       => 'button_set',
                    'title'      => esc_html__( 'Page Breadcrumb', 'bustro-toolkit' ),
                    'options'    => [
                        'default'  => esc_html__( 'Default', 'bustro-toolkit' ),
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default'    => 'default',
                    'dependency' => ['post_page_title', '!=', 'disabled'],
                ],
                [
                    'id'         => 'customize_page_title_style',
                    'type'       => 'button_set',
                    'title'      => esc_html__( 'Customize Style', 'bustro-toolkit' ),
                    'options'    => [
                        'yes' => esc_html__( 'Yes', 'bustro-toolkit' ),
                        'no'  => esc_html__( 'No', 'bustro-toolkit' ),
                    ],
                    'default'    => 'no',
                    'dependency' => ['post_page_title', '!=', 'disabled'],
                ],
                [
                    'type'       => 'subheading',
                    'content'    => esc_html__( 'Page Title Styling', 'bustro-toolkit' ),
                    'dependency' => [
                        ['post_page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
                [
                    'id'          => 'page_title_padding',
                    'type'        => 'spacing',
                    'title'       => esc_html__( 'Padding', 'bustro-toolkit' ),
                    'output'      => '.page-title-area',
                    'output_mode' => 'padding',
                    'dependency'  => [
                        ['post_page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
                [
                    'id'         => 'page_title_border',
                    'type'       => 'border',
                    'title'      => esc_html__( 'Border', 'bustro-toolkit' ),
                    'output'     => '.page-title-area',
                    'dependency' => [
                        ['post_page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
                [
                    'id'          => 'page_title_bg',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Background Color', 'bustro-toolkit' ),
                    'output'      => '.page-title-area',
                    'output_mode' => 'background-color',
                    'dependency'  => [
                        ['post_page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
                [
                    'id'         => 'page_title_typo',
                    'type'       => 'typography',
                    'title'      => esc_html( 'Typography', 'bustro-toolkit' ),
                    'output'     => '.page-title-area .page-title',
                    'dependency' => [
                        ['post_page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
                [
                    'id'         => 'page_breadcrumb_typo',
                    'type'       => 'typography',
                    'title'      => esc_html( 'Breadcrumb Typography', 'bustro-toolkit' ),
                    'output'     => '.page-title-area .breadcrumb, .page-title-area .breadcrumb a',
                    'dependency' => [
                        ['post_page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
                [
                    'id'          => 'page_title_dot',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Dots Color', 'bustro-toolkit' ),
                    'output'      => '.page-title-area .breadcrumb::before',
                    'output_mode' => 'background-color',
                    'dependency'  => [
                        ['post_page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
            ],
        ] );

        // Footer
        CSF::createSection( $this->post_prefix, [
            'title'  => esc_html__( 'Footer', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'notice',
                    'style'   => 'info',
                    'content' => esc_html__( 'If you used theme builder for post footer then disable default footer', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'post_default_footer',
                    'type'     => 'button_set',
                    'title'    => esc_html__( 'Default Footer', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Enable or Disable post default footer. Default comes form theme option', 'bustro-toolkit' ),
                    'options'  => [
                        'default'  => esc_html__( 'Default', 'bustro-toolkit' ),
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default'  => 'default',

                ],
                [
                    'type'       => 'notice',
                    'style'      => 'warning',
                    'content'    => esc_html__( 'You disabled default footer. Set your post footer form ', 'bustro-toolkit' ) . '<a href="' . esc_url( $this->template_builder_url ) . '">' . esc_html__( 'here', 'bustro-toolkit' ) . '</a>',
                    'dependency' => [
                        'post_default_footer', '==', 'disabled',
                    ],
                ],
            ],
        ] );
    }

    public function page_metaboxes() {
        CSF::createMetabox( $this->page_prefix, [
            'title'        => esc_html__( 'Bustro Page Options', 'bustro-toolkit' ),
            'post_type'    => 'page',
            'show_restore' => true,
        ] );

        // Page Layout
        CSF::createSection( $this->page_prefix, [
            'title'  => esc_html__( 'Layout', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Page Layout', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'content_layout',
                    'type'    => 'image_select',
                    'title'   => esc_html__( 'Content Layout', 'bustro-toolkit' ),
                    'options' => [
                        'boxed-layout'      => BT_ASSETS . '/img/options/boxed-layout.jpg',
                        'full-width-layout' => BT_ASSETS . '/img/options/full-width-layout.jpg',
                    ],
                    'default' => 'boxed-layout',
                    'desc'    => esc_html__( 'Select Page layout. Full width or In container', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'content_sidebar',
                    'type'    => 'image_select',
                    'title'   => esc_html__( 'Sidebar', 'bustro-toolkit' ),
                    'options' => [
                        'left-sidebar'  => BT_ASSETS . '/img/options/left-sidebar.jpg',
                        'right-sidebar' => BT_ASSETS . '/img/options/right-sidebar.jpg',
                        'no-sidebar'    => BT_ASSETS . '/img/options/no-sidebar.jpg',
                    ],
                    'default' => 'no-sidebar',
                    'desc'    => esc_html__( 'Select Page Sidebar. Left sidebar or right sidebar or No sidebar', 'bustro-toolkit' ),
                ],
                [
                    'id'         => 'content_spacing',
                    'type'       => 'spacing',
                    'title'      => esc_html__( 'Content Spacing', 'bustro-toolkit' ),
                    'show_units' => false,
                    'desc'       => esc_html__( 'Default top: 40px, right: 20px, bottom: 100px, left: 20px', 'bustro-toolkit' ),
                    'output'     => '.content-container',
                ],
            ],
        ] );

        // Header
        CSF::createSection( $this->page_prefix, [
            'title'  => esc_html__( 'Header', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'notice',
                    'style'   => 'info',
                    'content' => esc_html__( 'If you used theme builder for page header then disable default header', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'page_default_header',
                    'type'     => 'button_set',
                    'title'    => esc_html__( 'Default Header', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Enable or Disable page default header. Default comes form theme option', 'bustro-toolkit' ),
                    'options'  => [
                        'default'  => esc_html__( 'Default', 'bustro-toolkit' ),
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default'  => 'default',
                ],
                [
                    'type'       => 'notice',
                    'style'      => 'warning',
                    'content'    => esc_html__( 'You disabled default header. Set your page header form ', 'bustro-toolkit' ) . '<a href="' . esc_url( $this->template_builder_url ) . '">' . esc_html__( 'here', 'bustro-toolkit' ) . '</a>',
                    'dependency' => [
                        'page_default_header', '==', 'disabled',
                    ],
                ],
                [
                    'id'         => 'page_sticky_header',
                    'type'       => 'button_set',
                    'title'      => esc_html__( 'Sticky Header', 'bustro-toolkit' ),
                    'subtitle'   => esc_html__( 'It will stick header at the top when page scrolling. Default comes form theme option', 'bustro-toolkit' ),
                    'options'    => [
                        'default'  => esc_html__( 'Default', 'bustro-toolkit' ),
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default'    => 'default',
                    'dependency' => [
                        'page_default_header', '!=', 'disabled',
                    ],
                ],
            ],
        ] );

        // Page Title
        CSF::createSection( $this->page_prefix, [
            'title'  => esc_html__( 'Page Title', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'heading',
                    'content' => esc_html__( 'Page Title', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'page_title',
                    'type'    => 'button_set',
                    'title'   => esc_html__( 'Page Title', 'bustro-toolkit' ),
                    'options' => [
                        'default'  => esc_html__( 'Default', 'bustro-toolkit' ),
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default' => 'default',
                ],
                [
                    'id'         => 'page_title_type',
                    'type'       => 'button_set',
                    'title'      => esc_html__( 'Page Title Type', 'bustro-toolkit' ),
                    'options'    => [
                        'default' => esc_html__( 'Default', 'bustro-toolkit' ),
                        'custom'  => esc_html__( 'Custom', 'bustro-toolkit' ),
                    ],
                    'default'    => 'default',
                    'dependency' => ['page_title', '!=', 'disabled'],
                ],
                [
                    'id'         => 'page_custom_title',
                    'type'       => 'text',
                    'title'      => esc_html__( 'Custom Title', 'bustro-toolkit' ),
                    'dependency' => [
                        ['page_title', '!=', 'disabled'],
                        ['page_title_type', '==', 'custom'],
                    ],
                ],
                [
                    'id'         => 'page_breadcrumb',
                    'type'       => 'button_set',
                    'title'      => esc_html__( 'Page Breadcrumb', 'bustro-toolkit' ),
                    'options'    => [
                        'default'  => esc_html__( 'Default', 'bustro-toolkit' ),
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default'    => 'default',
                    'dependency' => ['page_title', '!=', 'disabled'],
                ],
                [
                    'id'         => 'customize_page_title_style',
                    'type'       => 'button_set',
                    'title'      => esc_html__( 'Customize Style', 'bustro-toolkit' ),
                    'options'    => [
                        'yes' => esc_html__( 'Yes', 'bustro-toolkit' ),
                        'no'  => esc_html__( 'No', 'bustro-toolkit' ),
                    ],
                    'default'    => 'no',
                    'dependency' => ['page_title', '!=', 'disabled'],
                ],
                [
                    'type'       => 'subheading',
                    'content'    => esc_html__( 'Page Title Styling', 'bustro-toolkit' ),
                    'dependency' => [
                        ['page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
                [
                    'id'          => 'page_title_padding',
                    'type'        => 'spacing',
                    'title'       => esc_html__( 'Padding', 'bustro-toolkit' ),
                    'output'      => '.page-title-area',
                    'output_mode' => 'padding',
                    'dependency'  => [
                        ['page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
                [
                    'id'         => 'page_title_border',
                    'type'       => 'border',
                    'title'      => esc_html__( 'Border', 'bustro-toolkit' ),
                    'output'     => '.page-title-area',
                    'dependency' => [
                        ['page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
                [
                    'id'          => 'page_title_bg',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Background Color', 'bustro-toolkit' ),
                    'output'      => '.page-title-area',
                    'output_mode' => 'background-color',
                    'dependency'  => [
                        ['page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
                [
                    'id'         => 'page_title_typo',
                    'type'       => 'typography',
                    'title'      => esc_html( 'Typography', 'bustro-toolkit' ),
                    'output'     => '.page-title-area .page-title',
                    'dependency' => [
                        ['page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
                [
                    'id'         => 'page_breadcrumb_typo',
                    'type'       => 'typography',
                    'title'      => esc_html( 'Breadcrumb Typography', 'bustro-toolkit' ),
                    'output'     => '.page-title-area .breadcrumb, .page-title-area .breadcrumb a',
                    'dependency' => [
                        ['page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
                [
                    'id'          => 'page_title_dot',
                    'type'        => 'color',
                    'title'       => esc_html__( 'Dots Color', 'bustro-toolkit' ),
                    'output'      => '.page-title-area .breadcrumb::before',
                    'output_mode' => 'background-color',
                    'dependency'  => [
                        ['page_title', '!=', 'disabled'],
                        ['customize_page_title_style', '==', 'yes'],
                    ],
                ],
            ],
        ] );

        // Footer
        CSF::createSection( $this->page_prefix, [
            'title'  => esc_html__( 'Footer', 'bustro-toolkit' ),
            'fields' => [
                [
                    'type'    => 'notice',
                    'style'   => 'info',
                    'content' => esc_html__( 'If you used theme builder for page footer then disable default footer', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'page_default_footer',
                    'type'     => 'button_set',
                    'title'    => esc_html__( 'Default Footer', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'Enable or Disable page default footer. Default comes form theme option', 'bustro-toolkit' ),
                    'options'  => [
                        'default'  => esc_html__( 'Default', 'bustro-toolkit' ),
                        'enabled'  => esc_html__( 'Enable', 'bustro-toolkit' ),
                        'disabled' => esc_html__( 'Disable', 'bustro-toolkit' ),
                    ],
                    'default'  => 'default',
                ],
                [
                    'type'       => 'notice',
                    'style'      => 'warning',
                    'content'    => esc_html__( 'You disabled default footer. Set your page footer form ', 'bustro-toolkit' ) . '<a href="' . esc_url( $this->template_builder_url ) . '">' . esc_html__( 'here', 'bustro-toolkit' ) . '</a>',
                    'dependency' => [
                        'page_default_footer', '==', 'disabled',
                    ],
                ],
            ],
        ] );
    }

    public function user_metaboxes() {
        // Create profile options
        CSF::createProfileOptions( $this->user_prefix, [
            'data_type' => 'serialize',
        ] );

        CSF::createSection( $this->user_prefix, [
            'fields' => [
                [
                    'title' => esc_html__( 'Bustro Author Options', 'bustro-toolkit' ),
                    'type'  => 'heading',
                ],
                [
                    'id'           => 'user_profile_image',
                    'type'         => 'media',
                    'library'      => 'image',
                    'title'        => esc_html__( 'Profile Picture', 'bustro-toolkit' ),
                    'button_title' => esc_html__( 'Choose Picture', 'bustro-toolkit' ),
                ],
                [
                    'id'      => 'user_title',
                    'type'    => 'text',
                    'title'   => esc_html__( 'User Title', 'bustro-toolkit' ),
                    'default' => esc_html__( 'Editor', 'bustro-toolkit' ),
                ],
                [
                    'id'     => 'user_address',
                    'type'   => 'fieldset',
                    'title'  => esc_html__( 'User Address', 'bustro-toolkit' ),
                    'fields' => [
                        [
                            'id'    => 'user_address_title',
                            'type'  => 'text',
                            'title' => esc_html__( 'Title', 'bustro-toolkit' ),
                        ],
                        [
                            'id'    => 'user_address_desc',
                            'type'  => 'textarea',
                            'title' => esc_html__( 'Description', 'bustro-toolkit' ),
                        ],
                    ],
                ],
                [
                    'id'           => 'user_social_links',
                    'type'         => 'repeater',
                    'title'        => esc_html__( 'User Social Links', 'bustro-toolkit' ),
                    'button_title' => esc_html__( 'Add New', 'bustro-toolkit' ),
                    'fields'       => [
                        [
                            'id'    => 'social_icon',
                            'type'  => 'icon',
                            'title' => esc_html__( 'Icon', 'bustro-toolkit' ),
                        ],
                        [
                            'id'    => 'social_link',
                            'type'  => 'text',
                            'title' => esc_html__( 'Link', 'bustro-toolkit' ),
                        ],
                    ],
                ],
            ],
        ] );
    }

    public function category_metaboxes() {
        CSF::createTaxonomyOptions( $this->category_prefix, [
            'title'        => esc_html__( 'Bustro Category Options', 'bustro-toolkit' ),
            'taxonomy'     => 'category',
            'show_restore' => true,
        ] );

        CSF::createSection( $this->category_prefix, [
            'fields' => [
                [
                    'id'      => 'category_thumbnail',
                    'type'    => 'media',
                    'title'   => esc_html__( 'Category Thumbnail', 'bustro-toolkit' ),
                    'library' => 'image',
                ],
                [
                    'id'    => 'category_icon',
                    'type'  => 'icon',
                    'title' => esc_html__( 'Category Icon', 'bustro-toolkit' ),
                ],
                [
                    'id'       => 'category_color',
                    'type'     => 'color',
                    'default'  => '#fb2614',
                    'title'    => esc_html__( 'Category Color', 'bustro-toolkit' ),
                    'subtitle' => esc_html__( 'For design purpose', 'bustro-toolkit' ),
                ],
            ],
        ] );
    }
}

Bustro_Metaboxes::instance()->initialize();