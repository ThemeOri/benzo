<?php
namespace BustroToolkit\TemplateBuilder;

use CSF;

defined( 'ABSPATH' ) || exit;

class Template_Metaboxes {

    protected static $instance = null;
    private $prefix            = 'bustro_template_meta';

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function initialize() {
        if ( ! class_exists( 'CSF' ) ) {
            return;
        }

        $this->init_metaboxes();
    }

    public function init_metaboxes() {
        CSF::createMetabox( $this->prefix, [
            'title'        => esc_html__( 'Template Settings', 'bustro-toolkit' ),
            'post_type'    => 'bustro_template',
            'show_restore' => true,
            'theme'        => 'dark',
            'data_type'    => 'unserialize',
        ] );

        CSF::createSection( $this->prefix, [
            'fields' => [
                [
                    'id'     => 'bustro_tb_settings',
                    'type'   => 'fieldset',
                    'title'  => esc_html__( 'Common Settings', 'bustro-toolkit' ),
                    'fields' => [
                        [
                            'id'          => 'template_type',
                            'type'        => 'select',
                            'title'       => esc_html__( 'Template Type', 'bustro-toolkit' ),
                            'placeholder' => esc_html__( 'Select Type', 'bustro-toolkit' ),
                            'options'     => [
                                'header'    => esc_html__( 'Header', 'bustro-toolkit' ),
                                'footer'    => esc_html__( 'Footer', 'bustro-toolkit' ),
                                'block'     => esc_html__( 'Block', 'bustro-toolkit' ),
                                'popup'     => esc_html__( 'Popup', 'bustro-toolkit' ),
                                'offcanvas' => esc_html__( 'OffCanvas', 'bustro-toolkit' ),
                            ],
                            'default'     => 'block',
                        ],
                        [
                            'id'         => 'popup_width',
                            'type'       => 'select',
                            'title'      => esc_html__( 'Popup Width', 'bustro-toolkit' ),
                            'subtitle'   => esc_html__( 'Select or type a value (PX)', 'bustro-toolkit' ),
                            'options'    => [
                                'full'   => esc_html__( 'Full', 'bustro-toolkit' ),
                                'custom' => esc_html__( 'Custom', 'bustro-toolkit' ),
                            ],
                            'default'    => 'custom',
                            'dependency' => ['template_type', '==', 'popup'],
                        ],
                        [
                            'id'         => 'set_popup_width',
                            'type'       => 'dimensions',
                            'title'      => esc_html__( 'Popup Width', 'bustro-toolkit' ),
                            'default'    => [
                                'width' => '820',
                            ],
                            'height'     => false,
                            'units'      => ['px'],
                            'show_units' => false,
                            'dependency' => ['template_type|popup_width', '==|==', 'popup|custom'],
                        ],
                        [
                            'id'         => 'popup_height',
                            'type'       => 'select',
                            'title'      => esc_html__( 'Popup Height', 'bustro-toolkit' ),
                            'subtitle'   => esc_html__( 'Set the popup max height.', 'bustro-toolkit' ),
                            'options'    => [
                                'fit_content' => esc_html__( 'Fit Content', 'bustro-toolkit' ),
                                'full'        => esc_html__( 'Full', 'bustro-toolkit' ),
                                'custom'      => esc_html__( 'Custom', 'bustro-toolkit' ),
                            ],
                            'default'    => 'fit_content',
                            'dependency' => ['template_type', '==', 'popup'],
                        ],
                        [
                            'id'         => 'set_popup_height',
                            'type'       => 'dimensions',
                            'title'      => esc_html__( 'Height', 'bustro-toolkit' ),
                            'default'    => [
                                'height' => '520',
                            ],
                            'width'      => false,
                            'units'      => ['px'],
                            'show_units' => false,
                            'dependency' => ['template_type|popup_height', '==|==', 'popup|custom'],
                        ],
                        [
                            'id'         => 'popup_position',
                            'type'       => 'select',
                            'title'      => esc_html__( 'Popup Position', 'bustro-toolkit' ),
                            'subtitle'   => esc_html__( 'Choose the popup position on page.', 'bustro-toolkit' ),
                            'options'    => [
                                'center-center' => esc_html__( 'Center Center', 'bustro-toolkit' ),
                                'center-left'   => esc_html__( 'Center Left', 'bustro-toolkit' ),
                                'center-right'  => esc_html__( 'Center Right', 'bustro-toolkit' ),
                                'bottom-center' => esc_html__( 'Bottom Center', 'bustro-toolkit' ),
                                'top-center'    => esc_html__( 'Top Center', 'bustro-toolkit' ),
                                'bottom-left'   => esc_html__( 'Bottom Left', 'bustro-toolkit' ),
                                'top-left'      => esc_html__( 'Top Left', 'bustro-toolkit' ),
                                'bottom-right'  => esc_html__( 'Bottom Right', 'bustro-toolkit' ),
                                'top-right'     => esc_html__( 'Top Right', 'bustro-toolkit' ),
                            ],
                            'default'    => 'center-center',
                            'dependency' => ['template_type', '==', 'popup'],
                        ],
                        [
                            'id'         => 'popup_overly_color',
                            'type'       => 'color',
                            'title'      => esc_html__( 'Popup Overly Color', 'bustro-toolkit' ),
                            'dependency' => ['template_type', '==', 'popup'],
                            'default'    => 'rgba(0, 0, 0, 0.5)',
                        ],
                        [
                            'id'         => 'popup_close_color',
                            'type'       => 'color',
                            'title'      => esc_html__( 'Popup Close Color', 'bustro-toolkit' ),
                            'dependency' => ['template_type', '==', 'popup'],
                            'default'    => '#fb2614',
                        ],
                        [
                            'id'         => 'popup_close_bg',
                            'type'       => 'color',
                            'title'      => esc_html__( 'Popup Close Color', 'bustro-toolkit' ),
                            'dependency' => ['template_type', '==', 'popup'],
                            'default'    => '#ffffff',
                        ],
                        [
                            'id'         => 'popup_close_size',
                            'type'       => 'dimensions',
                            'title'      => esc_html__( 'Popup Close Size', 'bustro-toolkit' ),
                            'dependency' => ['template_type', '==', 'popup'],
                            'units'      => ['px'],
                            'default'    => [
                                'width'  => '40',
                                'height' => '40',
                            ],
                            'show_units' => false,
                        ],
                        [
                            'id'         => 'popup_close_radius',
                            'type'       => 'number',
                            'title'      => esc_html__( 'Popup Close Radius', 'bustro-toolkit' ),
                            'dependency' => ['template_type', '==', 'popup'],
                        ],
                        [
                            'id'         => 'popup_delay',
                            'type'       => 'number',
                            'title'      => esc_html__( 'Popup Delay', 'bustro-toolkit' ),
                            'dependency' => ['template_type', '==', 'popup'],
                            'default'    => 3,
                            'subtitle'   => esc_html__( 'Show when page is loaded (Second).', 'bustro' ),
                        ],
                        [
                            'id'         => 'offcanvas_width',
                            'type'       => 'dimensions',
                            'title'      => esc_html__( 'Width', 'bustro-toolkit' ),
                            'height'     => false,
                            'units'      => ['px'],
                            'default'    => [
                                'width' => '420',
                            ],
                            'show_units' => false,
                            'dependency' => ['template_type', '==', 'offcanvas'],
                        ],
                    ],
                ],
                [
                    'id'           => 'bustro_tb_include',
                    'type'         => 'repeater',
                    'title'        => esc_html__( 'Display On', 'bustro-toolkit' ),
                    'subtitle'     => esc_html__( 'Select the locations where this item should be visible.', 'bustro-toolkit' ),
                    'button_title' => esc_html__( 'Add Display Rule', 'bustro-toolkit' ),
                    'dependency'   => ['template_type', 'any', 'header,footer,popup'],
                    'fields'       => [
                        [
                            'type'    => 'subheading',
                            'content' => esc_html__( 'Define Rule', 'bustro-toolkit' ),
                        ],
                        [
                            'id'      => 'rule',
                            'type'    => 'select',
                            'title'   => esc_html__( 'Display on', 'bustro-toolkit' ),
                            'options' => [
                                'entire_website'    => esc_html__( 'Entire Website', 'bustro-toolkit' ),
                                'all_pages'         => esc_html__( 'All Pages', 'bustro-toolkit' ),
                                'front_page'        => esc_html__( 'Front Page', 'bustro-toolkit' ),
                                'post_page'         => esc_html__( 'Post Page', 'bustro-toolkit' ),
                                'post_details'      => esc_html__( 'Post Details', 'bustro-toolkit' ),
                                'all_archive'       => esc_html__( 'All Archive', 'bustro-toolkit' ),
                                'date_archive'      => esc_html__( 'Date Archive', 'bustro-toolkit' ),
                                'author_archive'    => esc_html__( 'Author Archive', 'bustro-toolkit' ),
                                'search_page'       => esc_html__( 'Search Page', 'bustro-toolkit' ),
                                '404_page'          => esc_html__( '404 Page', 'bustro-toolkit' ),
                                'specific_pages'    => esc_html__( 'Specific Pages', 'bustro-toolkit' ),
                                'specific_posts'    => esc_html__( 'Specific Posts', 'bustro-toolkit' ),
                                'shop_page'         => esc_html__( 'Shop Page', 'bustro-toolkit' ),
                                'product_details'   => esc_html__( 'Product Details', 'bustro-toolkit' ),
                                'specific_products' => esc_html__( 'Specific Products', 'bustro-toolkit' ),
                            ],
                        ],
                        [
                            'id'          => 'page_ids',
                            'type'        => 'select',
                            'title'       => esc_html__( 'Select Pages', 'bustro-toolkit' ),
                            'placeholder' => esc_html__( 'Select Pages', 'bustro-toolkit' ),
                            'chosen'      => true,
                            'ajax'        => true,
                            'multiple'    => true,
                            'sortable'    => true,
                            'options'     => 'pages',
                            'dependency'  => ['rule', '==', 'specific_pages'],
                        ],
                        [
                            'id'          => 'posts_ids',
                            'type'        => 'select',
                            'title'       => esc_html__( 'Select Posts', 'bustro-toolkit' ),
                            'placeholder' => esc_html__( 'Select Posts', 'bustro-toolkit' ),
                            'chosen'      => true,
                            'ajax'        => true,
                            'multiple'    => true,
                            'sortable'    => true,
                            'options'     => 'posts',
                            'dependency'  => ['rule', '==', 'specific_posts'],
                        ],
                        [
                            'id'          => 'product_ids',
                            'type'        => 'select',
                            'title'       => esc_html__( 'Select Products', 'bustro-toolkit' ),
                            'placeholder' => esc_html__( 'Select Products', 'bustro-toolkit' ),
                            'chosen'      => true,
                            'ajax'        => true,
                            'multiple'    => true,
                            'sortable'    => true,
                            'options'     => 'post',
                            'query_args'  => [
                                'post_type' => 'product',
                            ],
                            'dependency'  => ['rule', '==', 'specific_products'],
                        ],
                    ],
                ],
                [
                    'id'           => 'bustro_tb_exclude',
                    'type'         => 'repeater',
                    'title'        => esc_html__( 'Hide On', 'bustro-toolkit' ),
                    'subtitle'     => esc_html__( 'Select the locations where this item should be visible.', 'bustro-toolkit' ),
                    'button_title' => esc_html__( 'Add Hide Rule', 'bustro-toolkit' ),
                    'dependency'   => ['template_type', 'any', 'header,footer,popup'],
                    'fields'       => [
                        [
                            'type'    => 'subheading',
                            'content' => esc_html__( 'Hide Rule', 'bustro-toolkit' ),
                        ],
                        [
                            'id'      => 'rule',
                            'type'    => 'select',
                            'title'   => esc_html__( 'Hide on', 'bustro-toolkit' ),
                            'options' => [
                                'entire_website'    => esc_html__( 'Entire Website', 'bustro-toolkit' ),
                                'all_pages'         => esc_html__( 'All Pages', 'bustro-toolkit' ),
                                'front_page'        => esc_html__( 'Front Page', 'bustro-toolkit' ),
                                'post_page'         => esc_html__( 'Post Page', 'bustro-toolkit' ),
                                'post_details'      => esc_html__( 'Post Details', 'bustro-toolkit' ),
                                'all_archive'       => esc_html__( 'All Archive', 'bustro-toolkit' ),
                                'date_archive'      => esc_html__( 'Date Archive', 'bustro-toolkit' ),
                                'author_archive'    => esc_html__( 'Author Archive', 'bustro-toolkit' ),
                                'search_page'       => esc_html__( 'Search Page', 'bustro-toolkit' ),
                                '404_page'          => esc_html__( '404 Page', 'bustro-toolkit' ),
                                'specific_pages'    => esc_html__( 'Specific Pages', 'bustro-toolkit' ),
                                'specific_posts'    => esc_html__( 'Specific Posts', 'bustro-toolkit' ),
                                'shop_page'         => esc_html__( 'Shop Page', 'bustro-toolkit' ),
                                'product_details'   => esc_html__( 'Product Details', 'bustro-toolkit' ),
                                'specific_products' => esc_html__( 'Specific Products', 'bustro-toolkit' ),
                            ],
                        ],
                        [
                            'id'          => 'page_ids',
                            'type'        => 'select',
                            'title'       => esc_html__( 'Select Pages', 'bustro-toolkit' ),
                            'placeholder' => esc_html__( 'Select Pages', 'bustro-toolkit' ),
                            'chosen'      => true,
                            'ajax'        => true,
                            'multiple'    => true,
                            'sortable'    => true,
                            'options'     => 'pages',
                            'dependency'  => ['rule', '==', 'specific_pages'],
                        ],
                        [
                            'id'          => 'posts_ids',
                            'type'        => 'select',
                            'title'       => esc_html__( 'Select Posts', 'bustro-toolkit' ),
                            'placeholder' => esc_html__( 'Select Posts', 'bustro-toolkit' ),
                            'chosen'      => true,
                            'ajax'        => true,
                            'multiple'    => true,
                            'sortable'    => true,
                            'options'     => 'posts',
                            'dependency'  => ['rule', '==', 'specific_posts'],
                        ],
                        [
                            'id'          => 'product_ids',
                            'type'        => 'select',
                            'title'       => esc_html__( 'Select Products', 'bustro-toolkit' ),
                            'placeholder' => esc_html__( 'Select Products', 'bustro-toolkit' ),
                            'chosen'      => true,
                            'ajax'        => true,
                            'multiple'    => true,
                            'sortable'    => true,
                            'options'     => 'post',
                            'query_args'  => [
                                'post_type' => 'product',
                            ],
                            'dependency'  => ['rule', '==', 'specific_products'],
                        ],
                    ],
                ],
            ],
        ] );
    }
}

Template_Metaboxes::instance()->initialize();